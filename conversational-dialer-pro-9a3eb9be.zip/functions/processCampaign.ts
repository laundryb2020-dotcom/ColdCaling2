import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Get all running campaigns
    const campaigns = await base44.asServiceRole.entities.Campaign.filter({ status: 'running' });

    const results = [];

    for (const campaign of campaigns) {
      try {
        // Reload campaign to get latest metadata
        const freshCampaign = await base44.asServiceRole.entities.Campaign.get(campaign.id);
        
        // Get leads for this campaign's lead group
        const leads = await base44.asServiceRole.entities.Lead.filter({ 
          group_id: campaign.lead_group_id,
          status: 'new'
        });

        if (leads.length === 0) {
          // No more leads to call - mark campaign as completed
          await base44.asServiceRole.entities.Campaign.update(campaign.id, {
            status: 'completed',
            completed_at: new Date().toISOString()
          });
          
          // Reset all dialing leads back to new
          const dialingLeads = await base44.asServiceRole.entities.Lead.filter({
            group_id: campaign.lead_group_id,
            status: 'dialing'
          });
          
          for (const lead of dialingLeads) {
            await base44.asServiceRole.entities.Lead.update(lead.id, {
              status: 'new'
            });
          }
          
          continue;
        }

        // Get available phone numbers for this campaign
        const phoneNumbers = freshCampaign.phone_number_ids && freshCampaign.phone_number_ids.length > 0
          ? await Promise.all(
              freshCampaign.phone_number_ids.map(id => 
                base44.asServiceRole.entities.PhoneNumber.get(id)
              )
            )
          : [];

        if (phoneNumbers.length === 0) {
          results.push({
            campaignId: campaign.id,
            error: 'No phone numbers configured'
          });
          continue;
        }

        // Check if campaign needs Vapi setup - if not, setup now
          let currentCampaign = freshCampaign;
          if (!currentCampaign.metadata?.vapi_assistant_id) {
            console.log(`Campaign ${currentCampaign.id} missing Vapi setup, setting up now...`);
            try {
              const setupResult = await base44.asServiceRole.functions.invoke('setupVapiCampaign', { 
                campaignId: currentCampaign.id 
              });
              console.log('Vapi setup result:', setupResult.data);
              // Reload campaign after setup with retry to ensure persistence
              await new Promise(resolve => setTimeout(resolve, 500));
              currentCampaign = await base44.asServiceRole.entities.Campaign.get(currentCampaign.id);
              console.log('Campaign reloaded after Vapi setup:', { id: currentCampaign.id, metadata: currentCampaign.metadata });
            } catch (setupError) {
              console.error(`Failed to setup Vapi for campaign ${currentCampaign.id}:`, setupError.message);
              await base44.asServiceRole.entities.ErrorLog.create({
                source: 'processCampaign',
                error_type: 'Vapi Auto-Setup Failed',
                error_message: setupError.message,
                context: { campaign_id: currentCampaign.id }
              });
              continue; // Skip this campaign
            }
          }

        // Process leads based on concurrent call settings
        const concurrentCalls = currentCampaign.settings?.concurrent_calls || 1;
        const leadsToCall = leads.slice(0, concurrentCalls);

        // Initiate calls with Vapi
        const callPromises = leadsToCall.map(async (lead, index) => {
          const phoneNumber = phoneNumbers[index % phoneNumbers.length];

          try {
            const vapiApiKey = Deno.env.get('VAPI_API_KEY');
            if (!vapiApiKey) {
              throw new Error('VAPI_API_KEY not configured');
            }

            // Create call record
            const callRecord = await base44.asServiceRole.entities.CallRecord.create({
              campaign_id: currentCampaign.id,
              lead_id: lead.id,
              phone_number_used: phoneNumber.number,
              lead_phone_number: lead.phone_number,
              status: 'initiated',
              started_at: new Date().toISOString()
            });

            // Get Vapi IDs from metadata (use currentCampaign which was reloaded after setup)
            const campaignMetadata = currentCampaign.metadata || {};
            const vapiPhoneIds = campaignMetadata.vapi_phone_number_ids || [];
            const phoneVapiId = vapiPhoneIds[index % vapiPhoneIds.length];

            if (!campaignMetadata.vapi_assistant_id || !phoneVapiId) {
              const errorMsg = `Campaign not synced to Vapi. Assistant: ${campaignMetadata.vapi_assistant_id}, Phone: ${phoneVapiId}`;
              await base44.asServiceRole.entities.ErrorLog.create({
                source: 'processCampaign',
                error_type: 'Vapi Setup Missing',
                error_message: errorMsg,
                context: { campaign_id: currentCampaign.id, phoneNumberId: phoneNumber.id }
              });
              throw new Error(errorMsg);
            }

            // Initiate Vapi call
            const callPayload = {
              phoneNumberId: phoneVapiId,
              assistantId: campaignMetadata.vapi_assistant_id,
              customer: {
                number: lead.phone_number,
                name: `${lead.first_name || ''} ${lead.last_name || ''}`.trim()
              },
              metadata: {
                campaignId: currentCampaign.id,
                leadId: lead.id,
                callRecordId: callRecord.id
              }
            };

            const response = await fetch('https://api.vapi.ai/call/phone', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${vapiApiKey}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify(callPayload)
            });

            if (!response.ok) {
              const error = await response.text();
              await base44.asServiceRole.entities.CallRecord.update(callRecord.id, {
                status: 'failed'
              });
              throw new Error(`Vapi API error: ${error}`);
            }

            const vapiCall = await response.json();

            // Update call record with Vapi call ID
            await base44.asServiceRole.entities.CallRecord.update(callRecord.id, {
              twilio_call_sid: vapiCall.id
            });

            // Update lead
            await base44.asServiceRole.entities.Lead.update(lead.id, {
              status: 'dialing',
              last_called_at: new Date().toISOString(),
              call_attempts: (lead.call_attempts || 0) + 1
            });

            return { success: true, leadId: lead.id, callRecordId: callRecord.id };
            } catch (error) {
            await base44.asServiceRole.entities.ErrorLog.create({
              source: 'processCampaign',
              error_type: 'Call Initiation Error',
              error_message: error.message,
              stack_trace: error.stack,
              context: { campaign_id: currentCampaign.id, lead_id: lead.id }
            });
            return { success: false, leadId: lead.id, error: error.message };
            }
            });

            const callResults = await Promise.all(callPromises);

            // Update campaign stats
            const successfulCalls = callResults.filter(r => r.success).length;
            await base44.asServiceRole.entities.Campaign.update(currentCampaign.id, {
            'stats.total_calls': (currentCampaign.stats?.total_calls || 0) + successfulCalls
            });

            results.push({
            campaignId: currentCampaign.id,
            callsInitiated: successfulCalls,
            results: callResults
            });

            } catch (error) {
            // Log campaign processing errors
            const campaignId = campaign?.id || 'unknown';
            await base44.asServiceRole.entities.ErrorLog.create({
            source: 'processCampaign',
            error_type: 'Campaign Processing Error',
            error_message: error.message,
            stack_trace: error.stack,
            context: {
            campaign_id: campaignId
            }
            });
            results.push({
            campaignId: campaignId,
            error: error.message
            });
            }
    }

    return Response.json({
      success: true,
      processed: campaigns.length,
      results
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});