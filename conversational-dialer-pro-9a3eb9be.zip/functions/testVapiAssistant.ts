import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    
    if (!vapiApiKey) {
      return Response.json({ error: 'VAPI_API_KEY not configured' }, { status: 500 });
    }

    // Create a simple test assistant
    const assistantPayload = {
      name: 'Test Assistant',
      firstMessage: 'Hello! This is a test call. Can you hear me?',
      model: {
        provider: 'openai',
        model: 'gpt-4o-mini',
        messages: [{
          role: 'system',
          content: 'You are a helpful test assistant. Keep responses under 20 words. Just confirm you can hear the user and end the call.'
        }]
      },
      voice: {
        provider: 'azure',
        voiceId: 'andrew'
      },
      recordingEnabled: true,
      endCallMessage: "Test complete. Goodbye!",
      endCallPhrases: ["goodbye", "end test", "hang up"]
    };

    const response = await fetch('https://api.vapi.ai/assistant', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${vapiApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(assistantPayload)
    });

    if (!response.ok) {
      const errorText = await response.text();
      return Response.json({ 
        error: 'Failed to create assistant', 
        details: errorText 
      }, { status: response.status });
    }

    const assistant = await response.json();

    // Now make a test call
    const payload = await req.json();
    const phoneNumber = payload.phoneNumber || '+13234017798';
    const vapiPhoneId = payload.vapiPhoneId;

    if (!vapiPhoneId) {
      return Response.json({ 
        success: true, 
        assistant,
        message: 'Assistant created but no phone number provided for test call'
      });
    }

    const callPayload = {
      phoneNumberId: vapiPhoneId,
      assistantId: assistant.id,
      customer: {
        number: phoneNumber
      }
    };

    const callResponse = await fetch('https://api.vapi.ai/call/phone', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${vapiApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(callPayload)
    });

    if (!callResponse.ok) {
      const errorText = await callResponse.text();
      return Response.json({ 
        success: true,
        assistant,
        callError: errorText 
      }, { status: 200 });
    }

    const call = await callResponse.json();

    return Response.json({
      success: true,
      assistant,
      call,
      message: 'Test call initiated successfully'
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});