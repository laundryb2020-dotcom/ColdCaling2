import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req).asServiceRole;
    const payload = await req.json();

    // Extract call record ID from automation trigger
    const callRecordId = payload.event?.entity_id || payload.callRecordId;
    if (!callRecordId) {
      return Response.json({ error: 'callRecordId required' }, { status: 400 });
    }

    // Get call record
    const callRecord = await base44.entities.CallRecord.get(callRecordId);
    if (!callRecord) {
      return Response.json({ error: 'CallRecord not found' }, { status: 404 });
    }

    // Only book if call was answered and has transcript
    if (callRecord.status !== 'completed' || !callRecord.transcript) {
      return Response.json({ success: false, reason: 'Call not completed or no transcript' });
    }

    // Get lead info for email
    const lead = await base44.entities.Lead.get(callRecord.lead_id);
    if (!lead || !lead.email) {
      return Response.json({ success: false, reason: 'No lead email' });
    }

    // Use LLM to extract appointment details from transcript
    const extractionResult = await base44.integrations.Core.InvokeLLM({
      prompt: `Extract appointment booking details from this call transcript. Return as JSON with: title (appointment title), start_time (ISO 8601 datetime), end_time (ISO 8601 datetime), notes (any special notes). If no appointment was booked, return null.

Transcript:
${callRecord.transcript}`,
      response_json_schema: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          start_time: { type: 'string' },
          end_time: { type: 'string' },
          notes: { type: 'string' }
        }
      }
    });

    const appointmentDetails = extractionResult;
    if (!appointmentDetails || !appointmentDetails.start_time || !appointmentDetails.end_time) {
      return Response.json({ success: false, reason: 'No appointment details extracted' });
    }

    // Book the appointment
    const bookingResult = await base44.functions.invoke('bookGoogleCalendarAppointment', {
      leadId: lead.id,
      campaignId: callRecord.campaign_id,
      callRecordId: callRecord.id,
      title: appointmentDetails.title || 'Demo Call',
      description: appointmentDetails.notes || '',
      start_time: appointmentDetails.start_time,
      end_time: appointmentDetails.end_time,
      attendee_email: lead.email,
      attendee_phone: lead.phone_number,
      notes: appointmentDetails.notes
    });

    return Response.json({
      success: true,
      appointment: bookingResult.data.appointment,
      googleCalendarLink: bookingResult.data.googleCalendarLink
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});