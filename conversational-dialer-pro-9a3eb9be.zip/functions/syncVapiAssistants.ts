import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req).asServiceRole;
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');

    if (!vapiApiKey) {
      return Response.json({ error: 'VAPI_API_KEY not configured' }, { status: 500 });
    }

    // Fetch all AI agents
    const agents = await base44.entities.AIAgent.list();
    const results = [];

    for (const agent of agents) {
      try {
        // Create or update Vapi assistant
        const assistantPayload = {
          name: agent.name,
          firstMessage: agent.greeting || `Hello, how can I help you today?`,
          model: {
            provider: 'openai',
            model: 'gpt-4o-mini',
            systemPrompt: agent.instructions,
            tools: agent.qualification_criteria?.length > 0 ? [
              {
                type: 'function',
                async: false,
                function: {
                  name: 'record_qualification_answers',
                  description: 'Record answers to qualification questions',
                  parameters: {
                    type: 'object',
                    properties: {
                      answers: {
                        type: 'object',
                        description: 'Qualification question answers'
                      }
                    }
                  }
                }
              }
            ] : []
          },
          voice: {
            provider: 'vapi',
            voiceId: agent.voice_gender === 'male' ? 'Aiden' : 'Alia'
          }
        };

        const response = await fetch('https://api.vapi.ai/assistant', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${vapiApiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(assistantPayload)
        });

        if (!response.ok) {
          const error = await response.text();
          results.push({
            agentId: agent.id,
            agentName: agent.name,
            success: false,
            error: error
          });
          continue;
        }

        const vapiAssistant = await response.json();

        // Store Vapi assistant ID in agent metadata
        await base44.entities.AIAgent.update(agent.id, {
          ...agent,
          metadata: {
            ...agent.metadata,
            vapi_assistant_id: vapiAssistant.id
          }
        });

        results.push({
          agentId: agent.id,
          agentName: agent.name,
          vapiAssistantId: vapiAssistant.id,
          success: true
        });
      } catch (error) {
        results.push({
          agentId: agent.id,
          agentName: agent.name,
          success: false,
          error: error.message
        });
      }
    }

    return Response.json({
      success: true,
      synced: results.filter(r => r.success).length,
      total: agents.length,
      results
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});