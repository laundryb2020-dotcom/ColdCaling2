import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { 
      leadId, 
      campaignId,
      callRecordId,
      title, 
      description, 
      startTime,
      start_time,
      endTime,
      end_time,
      attendeeEmail,
      attendee_email,
      attendeePhone,
      attendeeName,
      notes 
    } = await req.json();

    const start = startTime || start_time;
    const end = endTime || end_time;
    const email = attendeeEmail || attendee_email;

    if (!start || !end) {
      return Response.json({ error: 'Start time and end time are required' }, { status: 400 });
    }

    // Get Google Calendar access token
    const accessToken = await base44.asServiceRole.connectors.getAccessToken('googlecalendar');

    // Create calendar event
    const calendarEvent = {
      summary: title || 'Sales Appointment',
      description: description || notes || 'Appointment booked via VoiceFlow AI',
      start: {
        dateTime: start,
        timeZone: 'America/New_York'
      },
      end: {
        dateTime: end,
        timeZone: 'America/New_York'
      },
      attendees: email ? [{ email }] : [],
      reminders: {
        useDefault: false,
        overrides: [
          { method: 'email', minutes: 24 * 60 },
          { method: 'popup', minutes: 30 }
        ]
      }
    };

    // Create event in Google Calendar
    const response = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(calendarEvent)
    });

    if (!response.ok) {
      const error = await response.text();
      return Response.json({ error: 'Failed to create calendar event', details: error }, { status: response.status });
    }

    const createdEvent = await response.json();

    // Store appointment locally
    const appointment = await base44.asServiceRole.entities.Appointment.create({
      lead_id: leadId,
      campaign_id: campaignId,
      call_record_id: callRecordId,
      title: title || 'Sales Appointment',
      description: description || notes,
      start_time: start,
      end_time: end,
      attendee_email: email,
      attendee_phone: attendeePhone,
      google_calendar_event_id: createdEvent.id,
      google_calendar_link: createdEvent.htmlLink,
      status: 'scheduled',
      notes: notes
    });

    return Response.json({
      success: true,
      appointment,
      googleCalendarLink: createdEvent.htmlLink
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});