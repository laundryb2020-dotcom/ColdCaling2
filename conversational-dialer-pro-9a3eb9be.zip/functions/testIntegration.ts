import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Get a running campaign and lead
    const campaigns = await base44.asServiceRole.entities.Campaign.filter({ status: 'running' });
    
    if (campaigns.length === 0) {
      return Response.json({ 
        status: 'NO_RUNNING_CAMPAIGNS',
        message: 'No running campaigns found. Create and start a campaign first.'
      });
    }
    
    const campaign = campaigns[0];
    console.log('Found campaign:', campaign.id, campaign.name);
    
    // Get leads for this campaign
    const leads = await base44.asServiceRole.entities.Lead.filter({
      group_id: campaign.lead_group_id,
      status: 'new'
    });
    
    if (leads.length === 0) {
      return Response.json({
        status: 'NO_NEW_LEADS',
        campaign: campaign.id,
        message: 'No new leads in this campaign'
      });
    }
    
    const lead = leads[0];
    const agent = await base44.asServiceRole.entities.AIAgent.get(campaign.agent_id);
    
    console.log('Testing with:');
    console.log('Campaign:', campaign.name, campaign.id);
    console.log('Lead:', lead.first_name, lead.last_name, lead.phone_number);
    console.log('Agent:', agent.name, agent.id);
    
    // Simulate what Twilio would call
    const appUrl = Deno.env.get('BASE44_APP_URL');
    const twimlUrl = `${appUrl}/functions/handleCallTwiml?campaignId=${campaign.id}&leadId=${lead.id}`;
    
    console.log('TwiML URL would be:', twimlUrl);
    
    // Test the handleCallTwiml endpoint
    const response = await fetch(twimlUrl);
    const twiml = await response.text();
    
    return Response.json({
      status: 'SUCCESS',
      campaign: {
        id: campaign.id,
        name: campaign.name,
        agent: agent.name,
        agentId: agent.id,
        qualification_criteria: agent.qualification_criteria
      },
      lead: {
        id: lead.id,
        name: `${lead.first_name} ${lead.last_name}`,
        phone: lead.phone_number,
        company: lead.company
      },
      agent: {
        name: agent.name,
        persona: agent.persona,
        voice_gender: agent.voice_gender,
        greeting: agent.greeting,
        instructions_preview: agent.instructions.substring(0, 200) + '...',
        qualification_criteria: agent.qualification_criteria
      },
      twiml_response: twiml.substring(0, 500) + '...',
      twiml_valid: twiml.includes('<Response>') && twiml.includes('<Stream url=')
    });
    
  } catch (error) {
    return Response.json({ 
      status: 'ERROR',
      error: error.message 
    }, { status: 500 });
  }
});