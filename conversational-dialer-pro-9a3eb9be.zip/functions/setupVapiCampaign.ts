import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req).asServiceRole;
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    
    let campaignId;
    const payload = await req.json();
    
    // Handle automation trigger (event object) or direct function call
    if (payload.event?.entity_id) {
      campaignId = payload.event.entity_id;
    } else if (payload.campaignId) {
      campaignId = payload.campaignId;
    }

    if (!vapiApiKey) {
      return Response.json({ error: 'VAPI_API_KEY not configured' }, { status: 500 });
    }

    if (!campaignId) {
      return Response.json({ error: 'campaignId required' }, { status: 400 });
    }

    // Get campaign details
    const campaign = await base44.entities.Campaign.get(campaignId);
    if (!campaign) {
      return Response.json({ error: 'Campaign not found' }, { status: 404 });
    }

    // If campaign already has Vapi setup, skip and return existing IDs
    if (campaign.metadata?.vapi_assistant_id && campaign.metadata?.vapi_phone_number_ids?.length > 0) {
      console.log('Campaign already has Vapi setup:', { campaignId, assistantId: campaign.metadata.vapi_assistant_id });
      return Response.json({
        success: true,
        vapiAssistantId: campaign.metadata.vapi_assistant_id,
        vapiPhoneNumberIds: campaign.metadata.vapi_phone_number_ids,
        cached: true
      });
    }

    // Get agent details
    const agent = await base44.entities.AIAgent.get(campaign.agent_id);
    if (!agent) {
      return Response.json({ error: 'Agent not found' }, { status: 404 });
    }

    // Each campaign gets its own assistant
    let vapiAssistantId = null;

    // Get phone numbers (already have Vapi IDs from purchase)
    const phoneNumberIds = campaign.phone_number_ids || [];
    const vapiPhoneNumberIds = [];

    for (const phoneNumberId of phoneNumberIds) {
      const phoneNumber = await base44.entities.PhoneNumber.get(phoneNumberId);
      if (!phoneNumber) continue;

      let vapiPhoneId = phoneNumber.metadata?.vapi_phone_number_id;
      
      // If phone number not registered with Vapi, register it now
      if (!vapiPhoneId) {
        console.log(`Registering phone number ${phoneNumber.number} with Vapi...`);
        try {
          const registerResult = await base44.functions.invoke('registerVapiPhoneNumber', { 
            phoneNumberId: phoneNumber.id 
          });
          vapiPhoneId = registerResult.data.vapiPhoneNumberId;
        } catch (error) {
          console.error(`Failed to register phone ${phoneNumber.number}:`, error.message);
          continue;
        }
      }

      vapiPhoneNumberIds.push(vapiPhoneId);
    }

    // Create assistant for this campaign
    if (true) {
      const baseUrl = Deno.env.get('BASE44_APP_URL') || 'https://conversational-dialer-pro-9a3eb9be.base44.app';
      const serverUrl = `${baseUrl}/functions/callStatusWebhook`;

      const systemPrompt = agent.instructions || 'You are a helpful sales assistant.';

      const assistantPayload = {
        name: `${campaign.name} - ${agent.name}`.substring(0, 40),
        firstMessage: agent.greeting || `Hello, how can I help you today?`,
        model: {
          provider: 'openai',
          model: 'gpt-4o',
          messages: [{
            role: 'system',
            content: `${systemPrompt}\n\nAPPOINTMENT BOOKING INSTRUCTIONS: If the lead shows strong interest and is qualified, proactively suggest booking a follow-up appointment. Ask for their availability and confirm a time. For example: "Great! I'd like to schedule a follow-up call with you. What day next week works best for you?" Once they agree, confirm the time and say something like "Perfect, I've scheduled us for [day/time]. You'll receive a calendar invite."\n\nIMPORTANT: Keep responses concise and conversational. Speak naturally like a human would on the phone. Avoid long monologues. Always end the call with a polite closing statement when you've completed the conversation or booked a meeting.`
          }],
          temperature: 0.7,
          maxTokens: 200
        },
        voice: {
          provider: 'openai',
          voiceId: agent.voice_gender === 'male' ? 'onyx' : 'nova'
        },
        serverUrl: serverUrl,
        recordingEnabled: true,
        silenceTimeoutSeconds: 30,
        maxDurationSeconds: 1800,
        responseDelaySeconds: 0.4,
        llmRequestDelaySeconds: 0.1,
        numWordsToInterruptAssistant: 3,
        transcriber: {
          provider: 'openai',
          model: 'gpt-4o-mini-transcribe'
        },
        stopSpeakingPlan: {
          numWords: 3,
          voiceSeconds: 0.8,
          backoffSeconds: 0.4
        },
        startSpeakingPlan: {
          waitSeconds: 0.6,
          smartEndpointingEnabled: true
        }
      };

      const response = await fetch('https://api.vapi.ai/assistant', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${vapiApiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(assistantPayload)
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Failed to create Vapi assistant:', errorText);
        throw new Error(`Failed to create Vapi assistant: ${errorText}`);
      }

      const vapiAssistant = await response.json();
      vapiAssistantId = vapiAssistant.id;
      }

    // Update campaign with Vapi assistant ID
    const updatedCampaign = await base44.entities.Campaign.get(campaignId);
    const currentMetadata = updatedCampaign.metadata || {};
    
    await base44.entities.Campaign.update(campaignId, {
      metadata: {
        ...currentMetadata,
        vapi_assistant_id: vapiAssistantId,
        vapi_phone_number_ids: vapiPhoneNumberIds
      }
    });
    
    console.log('Campaign metadata updated:', { vapi_assistant_id: vapiAssistantId, vapi_phone_number_ids: vapiPhoneNumberIds });

    return Response.json({
      success: true,
      vapiAssistantId: vapiAssistantId,
      vapiPhoneNumberIds: vapiPhoneNumberIds
    });
  } catch (error) {
    console.error('Setup error:', error.message);

    try {
      const base44 = createClientFromRequest(req).asServiceRole;
      const logCampaignId = campaignId || 'unknown';
      await base44.entities.ErrorLog.create({
        source: 'setupVapiCampaign',
        error_type: 'Vapi Setup Error',
        error_message: error.message,
        stack_trace: error.stack,
        context: { campaignId: logCampaignId }
      });
    } catch (logError) {
      console.error('Failed to log setup error:', logError);
    }
    
    return Response.json({ error: error.message }, { status: 500 });
  }
});