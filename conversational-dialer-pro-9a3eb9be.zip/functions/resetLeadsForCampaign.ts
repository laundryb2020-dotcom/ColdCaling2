import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    
    // Handle entity automation payload
    const campaignId = payload.event?.entity_id || payload.campaignId;

    if (!campaignId) {
      return Response.json({ error: 'Missing campaignId' }, { status: 400 });
    }

    // Get the campaign (use payload.data if available from automation)
    const campaign = payload.data || await base44.asServiceRole.entities.Campaign.get(campaignId);
    
    if (!campaign) {
      return Response.json({ error: 'Campaign not found' }, { status: 404 });
    }

    const leadGroupId = campaign.lead_group_id || campaign.data?.lead_group_id;
    
    if (!leadGroupId) {
      return Response.json({ error: 'No lead group associated with campaign' }, { status: 400 });
    }

    // Get all leads in the group
    const leads = await base44.asServiceRole.entities.Lead.filter({ group_id: leadGroupId });

    // Reset all leads to 'new' status
    for (const lead of leads) {
      await base44.asServiceRole.entities.Lead.update(lead.id, {
        status: 'new',
        call_attempts: 0
      });
    }

    console.log(`Reset ${leads.length} leads to 'new' status for campaign ${campaignId}`);

    return Response.json({ 
      success: true, 
      leads_reset: leads.length 
    });

  } catch (error) {
    console.error('Error resetting leads:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});