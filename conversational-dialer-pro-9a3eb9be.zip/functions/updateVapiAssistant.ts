import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    const { assistantId } = await req.json();

    if (!vapiApiKey || !assistantId) {
      return Response.json({ error: 'Missing VAPI_API_KEY or assistantId' }, { status: 400 });
    }

    // Update assistant serverUrl
    const response = await fetch(`https://api.vapi.ai/assistant/${assistantId}`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${vapiApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        serverUrl: 'https://conversational-dialer-pro-9a3eb9be.base44.app/functions/callStatusWebhook'
      })
    });

    if (!response.ok) {
      const error = await response.text();
      return Response.json({ error, status: response.status }, { status: response.status });
    }

    const assistant = await response.json();
    return Response.json({ success: true, assistant });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});