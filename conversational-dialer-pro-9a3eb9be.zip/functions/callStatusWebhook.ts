import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  let errorLogged = false;
  
  try {
    const bodyText = await req.text();
    let body;
    try {
      body = JSON.parse(bodyText);
    } catch (parseError) {
      console.error('Failed to parse webhook body:', parseError.message, bodyText);
      throw new Error(`Invalid JSON in webhook: ${parseError.message}`);
    }
    
    console.log('Webhook received:', body);
    
    // Handle Vapi format
    const vapiCallId = body.call?.id;
    const vapiEventType = body.type;
    const vapiMetadata = body.call?.metadata;
    
    if (!vapiCallId) {
      return new Response('Missing call ID', { status: 400 });
    }
    
    // Extract IDs from Vapi metadata
    const callRecordId = vapiMetadata?.callRecordId;
    if (!callRecordId) {
      console.log('No callRecordId in metadata, skipping');
      return new Response('OK', { status: 200 });
    }

    const base44 = createClientFromRequest(req).asServiceRole;

    const callRecord = await base44.entities.CallRecord.get(callRecordId);
    if (!callRecord) {
      console.log('CallRecord not found:', callRecordId);
      return new Response('CallRecord not found', { status: 200 });
    }

    // Map Vapi events to call statuses
    const statusMap = {
      'call.started': 'in_progress',
      'call.updated': 'in_progress',
      'call.ended': 'completed',
      'call.failed': 'failed'
    };

    const endReasonMap = {
      'customer-hangup': 'hung_up',
      'assistant-hangup': 'hung_up',
      'no-answer': 'no_answer',
      'failed': 'failed',
      'busy': 'busy',
      'voicemail': 'voicemail',
      'unknown': 'other'
    };

    // Check if AI booked an appointment by looking at transcript/summary keywords
    const checkIfQualified = (transcript, summary, messages) => {
      const qualifyingKeywords = [
        'schedule',
        'appointment',
        'calendar',
        'booking',
        'confirmed',
        'booked',
        'time works',
        'sounds good',
        'great'
      ];
      
      const content = [
        transcript || '',
        summary || '',
        messages ? messages.map(m => m.content || '').join(' ') : ''
      ].join(' ').toLowerCase();
      
      return qualifyingKeywords.some(keyword => content.includes(keyword));
    };

    const updateData = {
      status: statusMap[vapiEventType] || 'in_progress'
    };

    // Parse call duration if available
    if (body.call?.duration) {
      updateData.duration_seconds = Math.round(body.call.duration);
    }

    // Handle call completion or failure
    if (vapiEventType === 'call.ended' || vapiEventType === 'call.failed') {
      updateData.ended_at = new Date().toISOString();
      
      const endReason = body.call?.endReason || 'unknown';
      updateData.outcome = endReasonMap[endReason] || 'other';

      // Capture transcript and summary if available
      if (body.call?.messages && body.call.messages.length > 0) {
        const transcript = body.call.messages
          .map(msg => `${msg.role}: ${msg.content}`)
          .join('\n');
        updateData.transcript = transcript;
        console.log('Transcript captured:', { callId: vapiCallId, length: transcript.length });
      }

      if (body.call?.summary) {
        updateData.ai_summary = body.call.summary;
      }

      // Check if call should be marked as qualified based on transcript/summary
      if (checkIfQualified(updateData.transcript, updateData.ai_summary, body.call?.messages)) {
        updateData.outcome = 'qualified';
        console.log('Call marked as qualified based on content analysis');
      }

      // Capture recording URL if available
      if (body.call?.recordingUrl) {
        updateData.recording_url = body.call.recordingUrl;
        console.log('Recording captured:', { callId: vapiCallId, url: body.call.recordingUrl });
      }

      // Handle sentiment analysis if available
      if (body.call?.sentiment) {
        updateData.sentiment = body.call.sentiment;
      }

      // Determine lead status based on end reason
      let leadStatus = 'no_answer';
      if (endReason === 'customer-hangup' || endReason === 'assistant-hangup') {
        leadStatus = 'answered';
      } else if (endReason === 'voicemail') {
        leadStatus = 'voicemail';
      } else if (endReason === 'busy') {
        leadStatus = 'answered'; // Busy counts as answered
      } else if (endReason === 'no-answer' || endReason === 'failed') {
        leadStatus = 'no_answer';
      }

      await base44.entities.Lead.update(callRecord.lead_id, { status: leadStatus });

      // Update campaign stats
      const campaign = await base44.entities.Campaign.get(callRecord.campaign_id);
      if (campaign) {
        const stats = campaign.stats || {};
        stats.total_calls = (stats.total_calls || 0) + 1;
        
        if (leadStatus === 'answered') {
          stats.answered = (stats.answered || 0) + 1;
        } else if (leadStatus === 'voicemail') {
          stats.voicemail = (stats.voicemail || 0) + 1;
        } else {
          stats.no_answer = (stats.no_answer || 0) + 1;
        }
        
        await base44.entities.Campaign.update(campaign.id, { stats });
      }

      // Log detailed call completion
      console.log('Call completed:', {
        callId: vapiCallId,
        leadId: callRecord.lead_id,
        endReason: endReason,
        leadStatus: leadStatus,
        duration: updateData.duration_seconds,
        hasTranscript: !!updateData.transcript,
        hasRecording: !!updateData.recording_url
      });
    }

    // Handle failed calls with detailed logging
    if (vapiEventType === 'call.failed') {
      console.error('Call failed:', {
        callId: vapiCallId,
        leadId: callRecord.lead_id,
        endReason: body.call?.endReason,
        errorMessage: body.call?.errorMessage
      });
      
      // Log failed call to ErrorLog
      await base44.entities.ErrorLog.create({
        source: 'callStatusWebhook',
        error_type: 'Call Failed',
        error_message: `Call failed for lead ${callRecord.lead_id}: ${body.call?.errorMessage || 'Unknown reason'}`,
        context: {
          campaign_id: callRecord.campaign_id,
          lead_id: callRecord.lead_id,
          call_id: vapiCallId,
          end_reason: body.call?.endReason,
          duration: body.call?.duration
        }
      });
    }

    await base44.entities.CallRecord.update(callRecordId, updateData);

    return new Response('OK', { status: 200 });

  } catch (error) {
    console.error('Webhook error:', error.message, error.stack);
    
    // Always try to log the error
    if (!errorLogged) {
      try {
        const base44 = createClientFromRequest(req).asServiceRole;
        await base44.entities.ErrorLog.create({
          source: 'callStatusWebhook',
          error_type: 'Webhook Processing Error',
          error_message: error.message || 'Unknown error',
          stack_trace: error.stack || '',
          context: {
            timestamp: new Date().toISOString()
          }
        });
        errorLogged = true;
      } catch (logError) {
        console.error('CRITICAL: Failed to log webhook error to database:', logError.message, error.message);
      }
    }
    
    return new Response('OK', { status: 200 });
  }
});