import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { campaignId, leadId, phoneNumberId } = await req.json();

    // Get campaign, lead, and phone number details
    const [campaign, lead, phoneNumber] = await Promise.all([
      base44.asServiceRole.entities.Campaign.get(campaignId),
      base44.asServiceRole.entities.Lead.get(leadId),
      base44.asServiceRole.entities.PhoneNumber.get(phoneNumberId)
    ]);

    if (!campaign || !lead || !phoneNumber) {
      return Response.json({ error: 'Campaign, lead, or phone number not found' }, { status: 404 });
    }

    const accountSid = Deno.env.get('TWILIO_ACCOUNT_SID');
    const authToken = Deno.env.get('TWILIO_AUTH_TOKEN');

    if (!accountSid || !authToken) {
      return Response.json({ error: 'Twilio credentials not configured' }, { status: 500 });
    }

    const authHeader = `Basic ${btoa(`${accountSid}:${authToken}`)}`;

    // Create TwiML URL WITH query params so Twilio sends them when calling the handler
    const baseUrl = Deno.env.get('BASE44_APP_URL');
    const twimlUrl = `${baseUrl}/functions/handleCallTwiml?campaignId=${campaignId}&leadId=${leadId}&agentId=${campaign.agent_id}`;
    const callbackUrl = `${baseUrl}/functions/callStatusWebhook`;

    // Create call record first
    const callRecord = await base44.asServiceRole.entities.CallRecord.create({
      campaign_id: campaignId,
      lead_id: leadId,
      phone_number_used: phoneNumber.number,
      lead_phone_number: lead.phone_number,
      status: 'initiated',
      started_at: new Date().toISOString()
    });

    // Initiate Twilio call
    const formData = new URLSearchParams();
    formData.append('From', phoneNumber.number);
    formData.append('To', lead.phone_number);
    formData.append('Url', twimlUrl);
    formData.append('StatusCallback', callbackUrl);
    formData.append('StatusCallbackMethod', 'POST');
    formData.append('StatusCallbackEvent', 'initiated,ringing,answered,completed');

    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Calls.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': authHeader,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData
      }
    );

    if (!response.ok) {
      const error = await response.text();
      await base44.asServiceRole.entities.CallRecord.update(callRecord.id, {
        status: 'failed'
      });
      return Response.json({ error: 'Failed to initiate call', details: error }, { status: response.status });
    }

    const twilioCall = await response.json();

    // Update call record with Twilio SID
    await base44.asServiceRole.entities.CallRecord.update(callRecord.id, {
      twilio_call_sid: twilioCall.sid
    });

    // Update lead
    await base44.asServiceRole.entities.Lead.update(leadId, {
      status: 'dialing',
      last_called_at: new Date().toISOString(),
      call_attempts: (lead.call_attempts || 0) + 1
    });

    return Response.json({
      success: true,
      callRecordId: callRecord.id,
      twilioCallSid: twilioCall.sid
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});