import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // CSV template with headers and sample row
    const csvContent = `first_name,last_name,phone_number,email,company,notes
John,Doe,+14155551234,john.doe@example.com,Acme Corp,Sample lead entry
Jane,Smith,+13105559876,jane.smith@example.com,Tech Solutions,Another sample lead`;

    return new Response(csvContent, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': 'attachment; filename=lead_upload_template.csv'
      }
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});