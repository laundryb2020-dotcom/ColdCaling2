import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req).asServiceRole;
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    const { campaignId, leadId, phoneNumberId } = await req.json();

    if (!vapiApiKey) {
      return Response.json({ error: 'VAPI_API_KEY not configured' }, { status: 500 });
    }

    // Fetch campaign, lead, agent, and phone number
    const [campaign, lead, phoneNumber] = await Promise.all([
      base44.entities.Campaign.get(campaignId),
      base44.entities.Lead.get(leadId),
      base44.entities.PhoneNumber.get(phoneNumberId)
    ]);

    if (!campaign || !lead || !phoneNumber) {
      return Response.json({ error: 'Campaign, lead, or phone number not found' }, { status: 404 });
    }

    // Get agent details
    const agent = await base44.entities.AIAgent.get(campaign.agent_id);
    if (!agent) {
      return Response.json({ error: 'Agent not found' }, { status: 404 });
    }

    // Create call record first
    const callRecord = await base44.entities.CallRecord.create({
      campaign_id: campaignId,
      lead_id: leadId,
      phone_number_used: phoneNumber.number,
      lead_phone_number: lead.phone_number,
      status: 'initiated',
      started_at: new Date().toISOString()
    });

    // Get Vapi assistant and phone number IDs from metadata
    const campaignMetadata = campaign.metadata || {};
    const phoneMetadata = phoneNumber.vapi_phone_number_id || phoneNumber.metadata?.vapi_phone_number_id;

    if (!campaignMetadata.vapi_assistant_id || !phoneMetadata) {
      return Response.json({
        error: 'Campaign or phone number not synced to Vapi. Run setupVapiCampaign first.',
        assistantSynced: !!campaignMetadata.vapi_assistant_id,
        phoneSynced: !!phoneMetadata
      }, { status: 400 });
    }

    // Initiate call with Vapi
    const callPayload = {
      phoneNumberId: phoneMetadata,
      assistantId: campaignMetadata.vapi_assistant_id,
      customer: {
        number: lead.phone_number,
        name: `${lead.first_name || ''} ${lead.last_name || ''}`.trim() || 'Customer'
      },
      metadata: {
        campaignId: campaignId,
        leadId: leadId,
        callRecordId: callRecord.id
      }
    };

    const response = await fetch('https://api.vapi.ai/call/phone', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${vapiApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(callPayload)
    });

    if (!response.ok) {
      const error = await response.text();
      console.error('Vapi call failed:', error);
      
      // Log Vapi error
      await base44.entities.ErrorLog.create({
        source: 'initiateVapiCall',
        error_type: 'Vapi API Error',
        error_message: `Failed to initiate Vapi call: ${error}`,
        context: {
          campaignId,
          leadId,
          phoneNumberId,
          httpStatus: response.status
        }
      });
      
      await base44.entities.CallRecord.update(callRecord.id, { status: 'failed' });
      return Response.json({ error: error }, { status: response.status });
    }

    const vapiCall = await response.json();

    // Update call record with Vapi call ID
    await base44.entities.CallRecord.update(callRecord.id, {
      twilio_call_sid: vapiCall.id // Store Vapi call ID here temporarily
    });

    // Update lead
    await base44.entities.Lead.update(leadId, {
      status: 'dialing',
      last_called_at: new Date().toISOString(),
      call_attempts: (lead.call_attempts || 0) + 1
    });

    return Response.json({
      success: true,
      callRecordId: callRecord.id,
      vapiCallId: vapiCall.id
    });
  } catch (error) {
    console.error('initiateVapiCall error:', error);
    
    try {
      await base44.asServiceRole.entities.ErrorLog.create({
        source: 'initiateVapiCall',
        error_type: 'Unexpected Error',
        error_message: error.message,
        stack_trace: error.stack
      });
    } catch (logError) {
      console.error('Failed to log error:', logError);
    }
    
    return Response.json({ error: error.message }, { status: 500 });
  }
});