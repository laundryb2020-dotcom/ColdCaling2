import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req).asServiceRole;
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    const twilioAccountSid = Deno.env.get('TWILIO_ACCOUNT_SID');
    const { phoneNumberId } = await req.json();

    if (!vapiApiKey || !twilioAccountSid) {
      return Response.json({ error: 'Missing API credentials' }, { status: 500 });
    }

    if (!phoneNumberId) {
      return Response.json({ error: 'phoneNumberId required' }, { status: 400 });
    }

    // Get phone number details
    const phoneNumber = await base44.entities.PhoneNumber.get(phoneNumberId);
    if (!phoneNumber) {
      return Response.json({ error: 'Phone number not found' }, { status: 404 });
    }

    // Register with Vapi as Twilio phone number
    const vapiPhonePayload = {
      provider: 'twilio',
      number: phoneNumber.number,
      twilioAccountSid: twilioAccountSid,
      twilioAuthToken: Deno.env.get('TWILIO_AUTH_TOKEN'),
      name: phoneNumber.friendly_name || phoneNumber.number
    };

    const response = await fetch('https://api.vapi.ai/phone-number', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${vapiApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(vapiPhonePayload)
    });

    if (!response.ok) {
      const error = await response.text();
      return Response.json({ error: error }, { status: response.status });
    }

    const vapiPhoneNumber = await response.json();

    // Store Vapi phone number ID in database
    await base44.entities.PhoneNumber.update(phoneNumberId, {
      ...phoneNumber,
      vapi_phone_number_id: vapiPhoneNumber.id
    });

    return Response.json({
      success: true,
      vapiPhoneNumberId: vapiPhoneNumber.id
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});