import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    const { assistantId } = await req.json();

    if (!vapiApiKey || !assistantId) {
      return Response.json({ error: 'Missing VAPI_API_KEY or assistantId' }, { status: 400 });
    }

    // Get assistant details from Vapi
    const response = await fetch(`https://api.vapi.ai/assistant/${assistantId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${vapiApiKey}`,
      }
    });

    if (!response.ok) {
      const error = await response.text();
      return Response.json({ error, status: response.status }, { status: response.status });
    }

    const assistant = await response.json();
    return Response.json({ assistant });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});