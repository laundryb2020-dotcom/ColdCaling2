import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
              console.log('=== Call Response Handler Started ===');
              console.log('Request method:', req.method);
              console.log('Request URL:', req.url);

              let speechResult = null;
              let callSid = null;
              let campaignId = null;
              let leadId = null;
              let agentId = null;

              try {
                const base44 = createClientFromRequest(req).asServiceRole;
                
                // Read body ONCE and reuse it
                let bodyText = '';
                if (req.method === 'POST') {
                  try {
                    bodyText = await req.text();
                    console.log('Raw POST body:', bodyText);
                    console.log('Body length:', bodyText.length);
                    console.log('Body type:', typeof bodyText);
                  } catch (readError) {
                    console.error('Failed to read body:', readError.message);
                    bodyText = '';
                  }
                }

                if (bodyText) {
                  try {
                    const params = new URLSearchParams(bodyText);
                    speechResult = params.get('SpeechResult');
                    callSid = params.get('CallSid');
                    console.log('Twilio params:', { speechResult, callSid });
                    console.log('All params from body:', Object.fromEntries(params.entries()));
                  } catch (parseError) {
                    console.error('Failed to parse POST body:', parseError.message);
                  }
                }

                // Use CallSid to look up the call record and get campaign/lead/agent IDs
                console.log('Looking up CallSid:', callSid);
                
                if (!callSid) {
                  console.error('ERROR: No CallSid found in request');
                  throw new Error('No CallSid provided by Twilio');
                }
                
                const callRecords = await base44.entities.CallRecord.filter({
                  twilio_call_sid: callSid
                });
                
                console.log('CallRecord lookup result:', { found: callRecords.length, callSid });
                
                if (callRecords.length === 0) {
                  console.error('ERROR: No CallRecord found for CallSid:', callSid);
                  throw new Error(`No CallRecord found for CallSid: ${callSid}`);
                }
                
                campaignId = callRecords[0].campaign_id;
                leadId = callRecords[0].lead_id;
                console.log('Found call record:', { campaignId, leadId });
                
                // Get agent ID from campaign
                const campaign = await base44.entities.Campaign.get(campaignId);
                agentId = campaign?.agent_id;
                console.log('Agent ID from campaign:', agentId);

                console.log('Final extracted params:', { campaignId, leadId, agentId, speechResult, callSid });

          if (!speechResult) {
            console.log('No speech result detected');
            return new Response(`<?xml version="1.0" encoding="UTF-8"?>
          <Response>
          <Say>I didn't catch that. Goodbye!</Say>
          <Hangup/>
          </Response>`, {
              status: 200,
              headers: { 'Content-Type': 'text/xml' }
            });
          }

          if (!campaignId || !leadId || !agentId) {
            console.error('Missing campaign, lead, or agent ID');
            return new Response(`<?xml version="1.0" encoding="UTF-8"?>
          <Response>
          <Say>Configuration error. Goodbye!</Say>
          <Hangup/>
          </Response>`, {
              status: 200,
              headers: { 'Content-Type': 'text/xml' }
            });
          }

          // Get agent and lead
          const [agent, lead] = await Promise.all([
            base44.entities.AIAgent.get(agentId),
            base44.entities.Lead.get(leadId)
          ]);
    
    // Generate AI response using ChatGPT
    const prompt = `${agent.instructions}

    You are speaking with ${lead.first_name} ${lead.last_name}${lead.company ? ` from ${lead.company}` : ''}.

    They just said: "${speechResult}"

    Respond naturally and conversationally. Keep your response concise (2-3 sentences max). 
    ${agent.qualification_criteria?.length > 0 ? `
    Your qualification criteria:
    ${agent.qualification_criteria.map((c, i) => `${i + 1}. ${c}`).join('\n')}
    ` : ''}`;

    const aiResponse = await base44.integrations.Core.InvokeLLM({
      prompt: prompt,
      add_context_from_internet: false
    });

    console.log('AI Response:', aiResponse);

    // Escape XML special characters in AI response
    const escapedAiResponse = String(aiResponse || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');

    // Update call record with transcript
    const callRecords = await base44.entities.CallRecord.filter({
      twilio_call_sid: callSid
    });

    if (callRecords.length > 0) {
      const existingTranscript = callRecords[0].transcript || '';
      const newTranscript = `${existingTranscript}\n\nProspect: ${speechResult}\nAgent: ${aiResponse}`;

      await base44.entities.CallRecord.update(callRecords[0].id, {
        transcript: newTranscript
      });
    }

    const baseUrl = Deno.env.get('BASE44_APP_URL');
    const handleResponseUrl = `${baseUrl}/functions/handleCallResponse?campaignId=${campaignId}&leadId=${leadId}&agentId=${agentId}`;
    const voice = agent.voice_gender === 'male' ? 'man' : 'woman';

    // Return TwiML with AI response and gather next input
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
<Say voice="${voice}">${escapedAiResponse}</Say>
<Gather input="speech" action="${handleResponseUrl}" method="POST" timeout="3" speechTimeout="auto">
<Pause length="1"/>
</Gather>
<Say voice="${voice}">Thanks for your time. Goodbye!</Say>
<Hangup/>
</Response>`;
    
    return new Response(twiml, {
      status: 200,
      headers: { 'Content-Type': 'text/xml' }
    });
    
  } catch (error) {
    console.error('Response handler error:', error);
    console.error('Error details:', error.message, error.stack);

    try {
      await base44.entities.ErrorLog.create({
        source: 'handleCallResponse',
        error_type: 'Response Handler Error',
        error_message: error.message,
        stack_trace: error.stack
      });
    } catch (logError) {
      console.error('Failed to log error:', logError);
    }
    
    return new Response(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
<Say>An error occurred. Goodbye!</Say>
<Hangup/>
</Response>`, {
      headers: { 'Content-Type': 'text/xml' }
    });
  }
});