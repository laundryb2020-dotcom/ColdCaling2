import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { callRecordId } = await req.json();

    if (!callRecordId) {
      return Response.json({ error: 'callRecordId required' }, { status: 400 });
    }

    // Get the call record to find the Vapi call ID
    const callRecord = await base44.asServiceRole.entities.CallRecord.get(callRecordId);
    
    if (!callRecord) {
      return Response.json({ error: 'Call record not found' }, { status: 404 });
    }

    const vapiCallId = callRecord.twilio_call_sid; // This should store the Vapi call ID
    
    if (!vapiCallId) {
      return Response.json({ 
        transcript: callRecord.transcript || '', 
        recordingUrl: callRecord.recording_url || '',
        summary: callRecord.ai_summary || ''
      });
    }

    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    if (!vapiApiKey) {
      return Response.json({ error: 'VAPI_API_KEY not configured' }, { status: 500 });
    }

    // Fetch full call details from Vapi
    const response = await fetch(`https://api.vapi.ai/call/${vapiCallId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${vapiApiKey}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      console.error('Failed to fetch Vapi call details:', response.status);
      // Fallback to stored data
      return Response.json({ 
        transcript: callRecord.transcript || '', 
        recordingUrl: callRecord.recording_url || '',
        summary: callRecord.ai_summary || ''
      });
    }

    const vapiCall = await response.json();

    // Extract transcript from messages
    let transcript = '';
    if (vapiCall.messages && vapiCall.messages.length > 0) {
      transcript = vapiCall.messages
        .map(msg => `${msg.role === 'user' ? 'Caller' : 'AI'}: ${msg.content}`)
        .join('\n');
    }

    return Response.json({
      transcript: transcript || callRecord.transcript || '',
      recordingUrl: vapiCall.recordingUrl || callRecord.recording_url || '',
      summary: vapiCall.summary || callRecord.ai_summary || '',
      duration: vapiCall.duration || callRecord.duration_seconds || 0,
      sentiment: vapiCall.sentiment || callRecord.sentiment || null
    });

  } catch (error) {
    console.error('Error fetching Vapi call details:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});