import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req).asServiceRole;
    const payload = await req.json();

    const callRecordId = payload.event?.entity_id;
    if (!callRecordId) {
      return Response.json({ error: 'No call record ID' }, { status: 400 });
    }

    // Get the call record
    const callRecord = await base44.entities.CallRecord.get(callRecordId);
    if (!callRecord || callRecord.outcome !== 'qualified') {
      console.log('Call not qualified or not found:', { callRecordId, outcome: callRecord?.outcome });
      return Response.json({ success: false, reason: 'Call not qualified' });
    }

    // Check if appointment already exists for this call
    const existingAppointments = await base44.entities.Appointment.filter({
      call_record_id: callRecordId
    });

    if (existingAppointments.length > 0) {
      console.log('Appointment already exists for this call');
      return Response.json({ success: false, reason: 'Appointment already exists' });
    }

    // Get the lead details
    const lead = await base44.entities.Lead.get(callRecord.lead_id);
    if (!lead) {
      return Response.json({ error: 'Lead not found' }, { status: 404 });
    }

    // Get campaign details
    const campaign = await base44.entities.Campaign.get(callRecord.campaign_id);

    // Set appointment time to 24 hours from now at 10am
    const appointmentDate = new Date();
    appointmentDate.setDate(appointmentDate.getDate() + 1);
    appointmentDate.setHours(10, 0, 0, 0);

    const endTime = new Date(appointmentDate);
    endTime.setHours(11, 0, 0, 0);

    // Create appointment
    const appointment = await base44.entities.Appointment.create({
      call_record_id: callRecordId,
      lead_id: callRecord.lead_id,
      campaign_id: callRecord.campaign_id,
      title: `Follow-up: ${lead.first_name} ${lead.last_name}`,
      description: `Qualified lead from campaign: ${campaign?.name || 'Unknown'}`,
      start_time: appointmentDate.toISOString(),
      end_time: endTime.toISOString(),
      attendee_email: lead.email,
      attendee_phone: lead.phone_number,
      status: 'scheduled',
      notes: `Auto-booked from qualified call. ${callRecord.ai_summary ? 'Call summary: ' + callRecord.ai_summary : ''}`
    });

    // Try to sync to Google Calendar if available
    try {
      const googleResult = await base44.functions.invoke('bookGoogleCalendarAppointment', {
        appointmentId: appointment.id,
        leadEmail: lead.email,
        leadName: `${lead.first_name} ${lead.last_name}`,
        startTime: appointmentDate.toISOString(),
        endTime: endTime.toISOString(),
        title: `Follow-up: ${lead.first_name} ${lead.last_name}`
      });

      // Update appointment with Google Calendar link if successful
      if (googleResult.data?.eventLink) {
        await base44.entities.Appointment.update(appointment.id, {
          google_calendar_event_id: googleResult.data.eventId,
          google_calendar_link: googleResult.data.eventLink
        });
      }
    } catch (error) {
      console.error('Failed to sync to Google Calendar:', error.message);
      // Continue even if Google Calendar sync fails
    }

    console.log('Appointment created:', { appointmentId: appointment.id, leadId: lead.id });

    return Response.json({
      success: true,
      appointmentId: appointment.id
    });

  } catch (error) {
    console.error('Error booking appointment:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});