import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import Header from "@/components/layout/Header";
import GlassCard from "@/components/ui/GlassCard";

export default function CampaignDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const campaignId = urlParams.get("id");

  const { data: campaign, isLoading } = useQuery({
    queryKey: ["campaign", campaignId],
    queryFn: () => base44.entities.Campaign.filter({ id: campaignId }).then((r) => r[0]),
    enabled: !!campaignId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950">
        <Header title="Campaign Details" subtitle="Loading..." />
        <div className="p-8">
          <div className="h-64 bg-slate-800/50 rounded-2xl animate-pulse" />
        </div>
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="min-h-screen bg-slate-950">
        <Header title="Campaign Not Found" subtitle="The campaign you're looking for doesn't exist" />
        <div className="p-8">
          <Link to={createPageUrl("Campaigns")}>
            <Button variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Campaigns
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <Header title={campaign.name} subtitle={campaign.description} />

      <div className="p-8 space-y-6">
        <Link to={createPageUrl("Campaigns")}>
          <Button variant="ghost" className="text-slate-400 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Campaigns
          </Button>
        </Link>

        <GlassCard className="p-6">
          <h3 className="font-semibold text-white text-lg mb-4">Campaign Overview</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div>
              <p className="text-sm text-slate-400 mb-1">Status</p>
              <p className="text-white font-medium capitalize">{campaign.status}</p>
            </div>
            <div>
              <p className="text-sm text-slate-400 mb-1">Total Calls</p>
              <p className="text-white font-medium">{campaign.stats?.total_calls || 0}</p>
            </div>
            <div>
              <p className="text-sm text-slate-400 mb-1">Answered</p>
              <p className="text-white font-medium">{campaign.stats?.answered || 0}</p>
            </div>
            <div>
              <p className="text-sm text-slate-400 mb-1">Qualified</p>
              <p className="text-white font-medium">{campaign.stats?.qualified || 0}</p>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-6">
          <h3 className="font-semibold text-white text-lg mb-4">Settings</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-400">Concurrent Calls</span>
              <span className="text-white">{campaign.settings?.concurrent_calls || 1}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Max Attempts</span>
              <span className="text-white">{campaign.settings?.max_attempts || 3}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Call Hours</span>
              <span className="text-white">
                {campaign.settings?.call_hours_start || "09:00"} - {campaign.settings?.call_hours_end || "17:00"}
              </span>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
}