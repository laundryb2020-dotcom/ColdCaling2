import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Calendar, Clock, User, Phone, Mail, ExternalLink } from "lucide-react";
import { format } from "date-fns";
import GlassCard from "@/components/ui/GlassCard";
import Header from "@/components/layout/Header";
import StatusBadge from "@/components/ui/StatusBadge";
import { Button } from "@/components/ui/button";

export default function Appointments() {
  const { data: appointments = [], isLoading } = useQuery({
    queryKey: ["appointments"],
    queryFn: () => base44.entities.Appointment.list("-start_time"),
  });

  const { data: leads = [] } = useQuery({
    queryKey: ["leads"],
    queryFn: () => base44.entities.Lead.list(),
  });

  const getLeadDetails = (leadId) => {
    return leads.find(l => l.id === leadId);
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Header 
        title="Appointments" 
        subtitle="Manage scheduled appointments from qualified calls"
      />

      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          {isLoading ? (
            <div className="text-center py-12 text-slate-400">Loading appointments...</div>
          ) : appointments.length === 0 ? (
            <GlassCard className="p-12">
              <div className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center mx-auto mb-4">
                  <Calendar className="w-8 h-8 text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">No Appointments Yet</h3>
                <p className="text-slate-400">
                  When your AI agents book appointments during calls, they'll appear here
                </p>
              </div>
            </GlassCard>
          ) : (
            <div className="space-y-4">
              {appointments.map((apt) => {
                const lead = getLeadDetails(apt.lead_id);
                const startDate = new Date(apt.start_time);
                const endDate = new Date(apt.end_time);

                return (
                  <GlassCard key={apt.id} className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <h3 className="text-lg font-semibold text-white">{apt.title}</h3>
                          <StatusBadge status={apt.status} />
                        </div>

                        {apt.description && (
                          <p className="text-slate-400 text-sm mb-4">{apt.description}</p>
                        )}

                        <div className="grid grid-cols-2 gap-4 mb-4">
                          <div className="flex items-center gap-2 text-sm">
                            <Calendar className="w-4 h-4 text-blue-400" />
                            <span className="text-slate-300">
                              {format(startDate, "MMM d, yyyy")}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Clock className="w-4 h-4 text-blue-400" />
                            <span className="text-slate-300">
                              {format(startDate, "h:mm a")} - {format(endDate, "h:mm a")}
                            </span>
                          </div>
                        </div>

                        {lead && (
                          <div className="space-y-2 border-t border-slate-800 pt-4">
                            <div className="flex items-center gap-2 text-sm">
                              <User className="w-4 h-4 text-slate-500" />
                              <span className="text-slate-300">
                                {lead.first_name} {lead.last_name}
                              </span>
                            </div>
                            {apt.attendee_phone && (
                              <div className="flex items-center gap-2 text-sm">
                                <Phone className="w-4 h-4 text-slate-500" />
                                <span className="text-slate-400">{apt.attendee_phone}</span>
                              </div>
                            )}
                            {apt.attendee_email && (
                              <div className="flex items-center gap-2 text-sm">
                                <Mail className="w-4 h-4 text-slate-500" />
                                <span className="text-slate-400">{apt.attendee_email}</span>
                              </div>
                            )}
                          </div>
                        )}

                        {apt.notes && (
                          <div className="mt-4 p-3 bg-slate-800/50 rounded-lg">
                            <p className="text-xs text-slate-400">{apt.notes}</p>
                          </div>
                        )}
                      </div>

                      <div>
                        {apt.google_calendar_link && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-slate-700 text-slate-300 hover:bg-slate-800"
                            onClick={() => window.open(apt.google_calendar_link, '_blank')}
                          >
                            <ExternalLink className="w-4 h-4 mr-2" />
                            Open in Calendar
                          </Button>
                        )}
                      </div>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}