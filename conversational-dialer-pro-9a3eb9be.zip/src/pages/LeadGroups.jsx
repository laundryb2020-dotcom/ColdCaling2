import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Plus, Users, Upload, MoreVertical, Edit, Trash2, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import Header from "@/components/layout/Header";
import GlassCard from "@/components/ui/GlassCard";
import LeadTable from "@/components/leads/LeadTable";
import LeadUploader from "@/components/leads/LeadUploader";

export default function LeadGroups() {
  const urlParams = new URLSearchParams(window.location.search);
  const actionParam = urlParams.get("action");

  const [showDialog, setShowDialog] = useState(actionParam === "new");
  const [editingGroup, setEditingGroup] = useState(null);
  const [formData, setFormData] = useState({ name: "", description: "" });
  const [selectedGroupId, setSelectedGroupId] = useState(null);
  const [showUploadDialog, setShowUploadDialog] = useState(false);

  const queryClient = useQueryClient();

  const { data: groups = [], isLoading } = useQuery({
    queryKey: ["leadGroups"],
    queryFn: () => base44.entities.LeadGroup.list("-created_date"),
  });

  const { data: leads = [] } = useQuery({
    queryKey: ["leads", selectedGroupId],
    queryFn: () =>
      selectedGroupId
        ? base44.entities.Lead.filter({ group_id: selectedGroupId }, "-created_date")
        : Promise.resolve([]),
    enabled: !!selectedGroupId,
  });

  const createGroupMutation = useMutation({
    mutationFn: (data) => base44.entities.LeadGroup.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["leadGroups"]);
      closeDialog();
    },
  });

  const updateGroupMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.LeadGroup.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(["leadGroups"]);
      closeDialog();
    },
  });

  const deleteGroupMutation = useMutation({
    mutationFn: (id) => base44.entities.LeadGroup.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(["leadGroups"]);
      if (selectedGroupId) setSelectedGroupId(null);
    },
  });

  const bulkCreateLeadsMutation = useMutation({
    mutationFn: (leads) => base44.entities.Lead.bulkCreate(leads),
    onSuccess: (result) => {
      queryClient.invalidateQueries(["leads", selectedGroupId]);
      queryClient.invalidateQueries(["leadGroups"]);
      setShowUploadDialog(false);
    },
  });

  const deleteLeadMutation = useMutation({
    mutationFn: (id) => base44.entities.Lead.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(["leads", selectedGroupId]);
      queryClient.invalidateQueries(["leadGroups"]);
    },
  });

  const openNewDialog = () => {
    setEditingGroup(null);
    setFormData({ name: "", description: "" });
    setShowDialog(true);
  };

  const openEditDialog = (group) => {
    setEditingGroup(group);
    setFormData({ name: group.name || "", description: group.description || "" });
    setShowDialog(true);
  };

  const closeDialog = () => {
    setShowDialog(false);
    setEditingGroup(null);
    setFormData({ name: "", description: "" });
  };

  const handleSave = () => {
    if (!formData.name.trim()) return;

    if (editingGroup) {
      updateGroupMutation.mutate({ id: editingGroup.id, data: formData });
    } else {
      createGroupMutation.mutate(formData);
    }
  };

  const handleImportComplete = (parsedLeads) => {
    const leadsWithGroupId = parsedLeads.map((lead) => ({
      ...lead,
      group_id: selectedGroupId,
    }));
    bulkCreateLeadsMutation.mutate(leadsWithGroupId);
  };

  if (selectedGroupId) {
    const selectedGroup = groups.find((g) => g.id === selectedGroupId);

    return (
      <div className="min-h-screen bg-slate-950">
        <Header title={selectedGroup?.name || "Lead Group"} subtitle={`${leads.length} leads`} />

        <div className="p-8 space-y-6">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={() => setSelectedGroupId(null)}
              className="text-slate-400 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Groups
            </Button>
            <Button
              onClick={() => setShowUploadDialog(true)}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
            >
              <Upload className="w-4 h-4 mr-2" />
              Import Leads
            </Button>
          </div>

          <LeadTable 
            leads={leads} 
            onDelete={(lead) => deleteLeadMutation.mutate(lead.id)} 
          />
        </div>

        <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
          <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-white">Import Leads</DialogTitle>
            </DialogHeader>
            <LeadUploader
              onComplete={handleImportComplete}
              onCancel={() => setShowUploadDialog(false)}
              isLoading={bulkCreateLeadsMutation.isPending}
            />
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <Header title="Lead Groups" subtitle="Organize and manage your leads" />

      <div className="p-8 space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-white">Your Lead Groups</h2>
          <Button
            onClick={openNewDialog}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Group
          </Button>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array(6)
              .fill(0)
              .map((_, i) => (
                <div key={i} className="h-40 bg-slate-800/50 rounded-2xl animate-pulse" />
              ))}
          </div>
        ) : groups.length === 0 ? (
          <GlassCard className="p-12 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">No Lead Groups</h3>
            <p className="text-slate-400 text-sm mb-6 max-w-sm mx-auto">
              Create your first lead group to organize and manage your contacts.
            </p>
            <Button
              onClick={openNewDialog}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Lead Group
            </Button>
          </GlassCard>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {groups.map((group, index) => (
              <GlassCard
                key={group.id}
                delay={index * 0.05}
                className="p-5 cursor-pointer"
                onClick={() => setSelectedGroupId(group.id)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="p-2.5 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20">
                    <Users className="w-5 h-5 text-blue-400" />
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                      <DropdownMenuItem
                        onClick={(e) => {
                          e.stopPropagation();
                          openEditDialog(group);
                        }}
                        className="text-slate-300 focus:text-white focus:bg-slate-800"
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteGroupMutation.mutate(group.id);
                        }}
                        className="text-red-400 focus:text-red-400 focus:bg-red-500/10"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <h3 className="font-semibold text-white text-lg mb-1">{group.name}</h3>
                <p className="text-sm text-slate-400 mb-4 line-clamp-2">{group.description || "No description"}</p>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-500">{group.total_leads || 0} leads</span>
                </div>
              </GlassCard>
            ))}
          </div>
        )}
      </div>

      <Dialog open={showDialog} onOpenChange={closeDialog}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white">{editingGroup ? "Edit Lead Group" : "Create Lead Group"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <label className="text-sm text-slate-400 mb-1.5 block">Group Name</label>
              <Input
                placeholder="e.g., Q1 Prospects"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
            <div>
              <label className="text-sm text-slate-400 mb-1.5 block">Description</label>
              <Textarea
                placeholder="Group description..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-slate-800/50 border-slate-700 text-white resize-none"
                rows={3}
              />
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <Button variant="outline" className="flex-1 border-slate-700 text-slate-300 hover:bg-slate-800" onClick={closeDialog}>
              Cancel
            </Button>
            <Button
              className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
              onClick={handleSave}
              disabled={!formData.name.trim()}
            >
              {editingGroup ? "Save Changes" : "Create Group"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}