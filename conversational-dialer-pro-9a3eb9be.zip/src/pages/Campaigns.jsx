import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Plus,
  Play,
  Pause,
  MoreVertical,
  Edit,
  Trash2,
  Phone,
  Users,
  Bot,
  TrendingUp,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import Header from "@/components/layout/Header";
import GlassCard from "@/components/ui/GlassCard";
import StatusBadge from "@/components/ui/StatusBadge";
import { Progress } from "@/components/ui/progress";

const defaultCampaign = {
  name: "",
  description: "",
  lead_group_id: "",
  agent_id: "",
  phone_number_ids: [],
  status: "draft",
  settings: {
    concurrent_calls: 1,
    cooldown_seconds: 5,
    max_attempts: 3,
    amd_enabled: true,
    local_presence: true,
    call_hours_start: "09:00",
    call_hours_end: "17:00",
  },
};

export default function Campaigns() {
  const urlParams = new URLSearchParams(window.location.search);
  const actionParam = urlParams.get("action");

  const [showDialog, setShowDialog] = useState(actionParam === "new");
  const [editingCampaign, setEditingCampaign] = useState(null);
  const [formData, setFormData] = useState(defaultCampaign);
  const [currentStep, setCurrentStep] = useState(0);
  const [setupingCampaignId, setSetupingCampaignId] = useState(null);

  const queryClient = useQueryClient();

  const { data: campaigns = [], isLoading } = useQuery({
    queryKey: ["campaigns"],
    queryFn: () => base44.entities.Campaign.list("-created_date"),
  });

  const { data: leadGroups = [] } = useQuery({
    queryKey: ["leadGroups"],
    queryFn: () => base44.entities.LeadGroup.list(),
  });

  const { data: agents = [] } = useQuery({
    queryKey: ["agents"],
    queryFn: () => base44.entities.AIAgent.list(),
  });

  const { data: phoneNumbers = [] } = useQuery({
    queryKey: ["phoneNumbers"],
    queryFn: () => base44.entities.PhoneNumber.list(),
  });

  const createCampaignMutation = useMutation({
    mutationFn: async (data) => {
      const campaign = await base44.entities.Campaign.create(data);
      // Setup Vapi asynchronously - don't block on it
      base44.functions.invoke('setupVapiCampaign', { campaignId: campaign.id }).catch(error => {
        console.error('Vapi setup warning:', error);
      });
      return campaign;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["campaigns"]);
      closeDialog();
    },
    onError: (error) => {
      console.error('Failed to create campaign:', error);
      alert('Failed to create campaign: ' + error.message);
    }
  });

  const updateCampaignMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Campaign.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(["campaigns"]);
      closeDialog();
    },
  });

  const deleteCampaignMutation = useMutation({
    mutationFn: (id) => base44.entities.Campaign.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(["campaigns"]);
    },
  });

  const openNewDialog = () => {
    setEditingCampaign(null);
    setFormData(defaultCampaign);
    setCurrentStep(0);
    setShowDialog(true);
  };

  const openEditDialog = (campaign) => {
    setEditingCampaign(campaign);
    setFormData({
      name: campaign.name || "",
      description: campaign.description || "",
      lead_group_id: campaign.lead_group_id || "",
      agent_id: campaign.agent_id || "",
      phone_number_ids: campaign.phone_number_ids || [],
      status: campaign.status || "draft",
      settings: campaign.settings || defaultCampaign.settings,
    });
    setCurrentStep(0);
    setShowDialog(true);
  };

  const closeDialog = () => {
    setShowDialog(false);
    setEditingCampaign(null);
    setFormData(defaultCampaign);
    setCurrentStep(0);
  };

  const handleSave = () => {
    if (!formData.name.trim() || !formData.lead_group_id || !formData.agent_id || formData.phone_number_ids.length === 0) return;

    if (editingCampaign) {
      updateCampaignMutation.mutate({ id: editingCampaign.id, data: formData });
    } else {
      createCampaignMutation.mutate(formData);
    }
  };

  const toggleCampaignStatus = async (campaign) => {
    const newStatus = campaign.status === "running" ? "paused" : "running";

    // If starting campaign, setup Vapi first and wait for it
    if (newStatus === "running") {
      try {
        setSetupingCampaignId(campaign.id);
        console.log('Starting Vapi setup for campaign:', campaign.id);
        const result = await base44.functions.invoke('setupVapiCampaign', { campaignId: campaign.id });
        console.log('Vapi setup successful:', result.data);

        // Small delay to ensure DB sync
        await new Promise(resolve => setTimeout(resolve, 500));

        // Refresh campaign data - wait for refetch to complete
        await queryClient.refetchQueries({ queryKey: ["campaigns"] });
        const updatedCampaign = await base44.entities.Campaign.get(campaign.id);

        // Now update campaign status to running
        await base44.entities.Campaign.update(campaign.id, { status: newStatus });
        queryClient.invalidateQueries(["campaigns"]);
      } catch (error) {
        console.error('Failed to setup or update campaign:', error);
        alert('Failed to start campaign. Please try again.');
      } finally {
        setSetupingCampaignId(null);
      }
    } else {
      updateCampaignMutation.mutate({
        id: campaign.id,
        data: { ...campaign, status: newStatus },
      });
    }
  };

  const leadGroupMap = Object.fromEntries(leadGroups.map((g) => [g.id, g]));
  const agentMap = Object.fromEntries(agents.map((a) => [a.id, a]));

  return (
    <div className="min-h-screen bg-slate-950">
      <Header title="Campaigns" subtitle="Manage your auto-dialing campaigns" />

      <div className="p-8 space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-white">Your Campaigns</h2>
          <Button
            onClick={openNewDialog}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Campaign
          </Button>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 gap-4">
            {Array(3)
              .fill(0)
              .map((_, i) => (
                <div key={i} className="h-48 bg-slate-800/50 rounded-2xl animate-pulse" />
              ))}
          </div>
        ) : campaigns.length === 0 ? (
          <GlassCard className="p-12 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center mx-auto mb-4">
              <Phone className="w-8 h-8 text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">No Campaigns Yet</h3>
            <p className="text-slate-400 text-sm mb-6 max-w-sm mx-auto">
              Create your first campaign to start auto-dialing leads with AI-powered conversations.
            </p>
            <Button
              onClick={openNewDialog}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Campaign
            </Button>
          </GlassCard>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {campaigns.map((campaign, index) => {
              const leadGroup = leadGroupMap[campaign.lead_group_id];
              const agent = agentMap[campaign.agent_id];
              const stats = campaign.stats || {};
              const totalCalls = stats.total_calls || 0;
              const answered = stats.answered || 0;
              const qualified = stats.qualified || 0;

              return (
                <GlassCard key={campaign.id} delay={index * 0.05} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-white text-xl">{campaign.name} <span className="text-slate-400 text-sm">({campaign.id})</span></h3>
                          <StatusBadge status={campaign.status} />
                      </div>
                      {campaign.description && (
                        <p className="text-sm text-slate-400 mb-3">{campaign.description}</p>
                      )}
                      <div className="flex items-center gap-6 text-sm text-slate-500">
                        <div className="flex items-center gap-1.5">
                          <Users className="w-4 h-4" />
                          <span>{leadGroup?.name || "Unknown Group"}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Bot className="w-4 h-4" />
                          <span>{agent?.name || "Unknown Agent"}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {campaign.status === "running" || campaign.status === "paused" ? (
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => toggleCampaignStatus(campaign)}
                          className="text-slate-400 hover:text-white"
                          disabled={setupingCampaignId === campaign.id}
                        >
                          {setupingCampaignId === campaign.id ? (
                            <Loader2 className="w-5 h-5 animate-spin" />
                          ) : campaign.status === "running" ? (
                            <Pause className="w-5 h-5" />
                          ) : (
                            <Play className="w-5 h-5" />
                          )}
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => toggleCampaignStatus(campaign)}
                          className="bg-green-500 hover:bg-green-600"
                        >
                          {setupingCampaignId === campaign.id ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                              Setting up...
                            </>
                          ) : (
                            <>
                              <Play className="w-4 h-4 mr-1" />
                              Start
                            </>
                          )}
                        </Button>
                      )}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                          <DropdownMenuItem
                            onClick={() => openEditDialog(campaign)}
                            className="text-slate-300 focus:text-white focus:bg-slate-800"
                          >
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => deleteCampaignMutation.mutate(campaign.id)}
                            className="text-red-400 focus:text-red-400 focus:bg-red-500/10"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>

                  {/* Progress */}
                  {totalCalls > 0 && (
                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-slate-400">Progress</span>
                        <span className="text-white font-medium">
                          {totalCalls} calls • {answered} answered • {qualified} qualified
                        </span>
                      </div>
                      <Progress value={(answered / totalCalls) * 100} className="h-2" />
                    </div>
                  )}

                  {/* Stats Grid */}
                  <div className="grid grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">{totalCalls}</div>
                      <div className="text-xs text-slate-500">Total Calls</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-emerald-400">{answered}</div>
                      <div className="text-xs text-slate-500">Answered</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-400">{qualified}</div>
                      <div className="text-xs text-slate-500">Qualified</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-400">
                        {answered > 0 ? Math.round((qualified / answered) * 100) : 0}%
                      </div>
                      <div className="text-xs text-slate-500">Conversion</div>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-slate-800">
                    <Link
                      to={createPageUrl("CampaignDetail") + `?id=${campaign.id}`}
                      className="text-sm text-blue-400 hover:text-blue-300 inline-flex items-center gap-1"
                    >
                      View Details
                      <TrendingUp className="w-4 h-4" />
                    </Link>
                  </div>
                </GlassCard>
              );
            })}
          </div>
        )}
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={showDialog} onOpenChange={closeDialog}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingCampaign ? "Edit Campaign" : "Create Campaign"}
            </DialogTitle>
          </DialogHeader>

          <Tabs value={String(currentStep)} onValueChange={(v) => setCurrentStep(Number(v))}>
            <TabsList className="grid w-full grid-cols-3 bg-slate-800/50">
              <TabsTrigger value="0">Basic Info</TabsTrigger>
              <TabsTrigger value="1">Resources</TabsTrigger>
              <TabsTrigger value="2">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="0" className="space-y-4 mt-4">
              <div>
                <label className="text-sm text-slate-400 mb-1.5 block">Campaign Name</label>
                <Input
                  placeholder="e.g., Q1 Outreach Campaign"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-slate-800/50 border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-1.5 block">Description</label>
                <Textarea
                  placeholder="Campaign description..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="bg-slate-800/50 border-slate-700 text-white resize-none"
                  rows={3}
                />
              </div>
            </TabsContent>

            <TabsContent value="1" className="space-y-4 mt-4">
              <div>
                <label className="text-sm text-slate-400 mb-1.5 block">Lead Group</label>
                <Select value={formData.lead_group_id} onValueChange={(value) => setFormData({ ...formData, lead_group_id: value })}>
                  <SelectTrigger className="bg-slate-800/50 border-slate-700 text-white">
                    <SelectValue placeholder="Select lead group" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-800">
                    {leadGroups.map((group) => (
                      <SelectItem key={group.id} value={group.id} className="text-slate-300 focus:text-white focus:bg-slate-800">
                        {group.name} ({group.total_leads || 0} leads)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-1.5 block">AI Agent</label>
                <Select value={formData.agent_id} onValueChange={(value) => setFormData({ ...formData, agent_id: value })}>
                  <SelectTrigger className="bg-slate-800/50 border-slate-700 text-white">
                    <SelectValue placeholder="Select AI agent" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-800">
                    {agents.map((agent) => (
                      <SelectItem key={agent.id} value={agent.id} className="text-slate-300 focus:text-white focus:bg-slate-800">
                        {agent.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-1.5 block">Phone Numbers</label>
                <Select 
                  value={formData.phone_number_ids[0] || ""} 
                  onValueChange={(value) => setFormData({ ...formData, phone_number_ids: [value] })}
                >
                  <SelectTrigger className="bg-slate-800/50 border-slate-700 text-white">
                    <SelectValue placeholder="Select phone number" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-800">
                    {phoneNumbers.filter(p => p.status === 'active').map((phone) => (
                      <SelectItem key={phone.id} value={phone.id} className="text-slate-300 focus:text-white focus:bg-slate-800">
                        {phone.number} - {phone.region}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {phoneNumbers.filter(p => p.status === 'active').length === 0 && (
                  <p className="text-xs text-amber-400 mt-1">
                    No active phone numbers. <Link to={createPageUrl("PhoneNumbers")} className="underline">Buy a number</Link>
                  </p>
                )}
              </div>
            </TabsContent>

            <TabsContent value="2" className="space-y-4 mt-4">
              <div>
                <label className="text-sm text-slate-400 mb-1.5 block">Concurrent Calls</label>
                <Input
                  type="number"
                  min="1"
                  max="10"
                  value={formData.settings.concurrent_calls}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      settings: { ...formData.settings, concurrent_calls: Number(e.target.value) },
                    })
                  }
                  className="bg-slate-800/50 border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-1.5 block">Max Attempts per Lead</label>
                <Input
                  type="number"
                  min="1"
                  max="5"
                  value={formData.settings.max_attempts}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      settings: { ...formData.settings, max_attempts: Number(e.target.value) },
                    })
                  }
                  className="bg-slate-800/50 border-slate-700 text-white"
                />
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex gap-3 pt-2">
            <Button variant="outline" className="flex-1 border-slate-700 text-slate-300 hover:bg-slate-800" onClick={closeDialog}>
              Cancel
            </Button>
            <Button
              className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
              onClick={handleSave}
              disabled={!formData.name.trim() || !formData.lead_group_id || !formData.agent_id || formData.phone_number_ids.length === 0 || createCampaignMutation.isPending || updateCampaignMutation.isPending}
            >
              {(createCampaignMutation.isPending || updateCampaignMutation.isPending) ? "Saving..." : editingCampaign ? "Save Changes" : "Create Campaign"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}