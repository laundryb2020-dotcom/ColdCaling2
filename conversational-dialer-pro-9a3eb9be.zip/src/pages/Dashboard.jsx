import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Phone, Users, Bot, TrendingUp, PhoneCall, CheckCircle2, XCircle } from "lucide-react";
import Header from "@/components/layout/Header";
import GlassCard from "@/components/ui/GlassCard";
import StatsCard from "@/components/ui/StatsCard";
import { format } from "date-fns";

export default function Dashboard() {
  const { data: campaigns = [] } = useQuery({
    queryKey: ["campaigns"],
    queryFn: () => base44.entities.Campaign.list("-created_date", 10),
  });

  const { data: callRecords = [] } = useQuery({
    queryKey: ["recentCalls"],
    queryFn: () => base44.entities.CallRecord.list("-created_date", 20),
  });

  const { data: leadGroups = [] } = useQuery({
    queryKey: ["leadGroups"],
    queryFn: () => base44.entities.LeadGroup.list(),
  });

  const { data: agents = [] } = useQuery({
    queryKey: ["agents"],
    queryFn: () => base44.entities.AIAgent.list(),
  });

  // Calculate stats
  const totalCalls = callRecords.length;
  const answeredCalls = callRecords.filter((c) => c.status === "completed" || c.status === "in_progress").length;
  const qualifiedLeads = callRecords.filter((c) => c.outcome === "qualified").length;
  const activeCampaigns = campaigns.filter((c) => c.status === "running").length;

  const answerRate = totalCalls > 0 ? Math.round((answeredCalls / totalCalls) * 100) : 0;

  return (
    <div className="min-h-screen bg-slate-950">
      <Header title="Dashboard" subtitle="Overview of your auto-dialer performance" />

      <div className="p-8 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title="Total Calls"
            value={totalCalls}
            subtitle="All time"
            icon={Phone}
            trend={{ direction: "up", value: "12%" }}
          />
          <StatsCard
            title="Answer Rate"
            value={`${answerRate}%`}
            subtitle={`${answeredCalls} answered`}
            icon={PhoneCall}
            trend={{ direction: "up", value: "5%" }}
          />
          <StatsCard
            title="Qualified Leads"
            value={qualifiedLeads}
            subtitle="From calls"
            icon={CheckCircle2}
            trend={{ direction: "up", value: "8%" }}
          />
          <StatsCard
            title="Active Campaigns"
            value={activeCampaigns}
            subtitle={`${campaigns.length} total`}
            icon={TrendingUp}
          />
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <GlassCard className="p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Users className="w-5 h-5 text-blue-400" />
              </div>
              <h3 className="font-semibold text-white">Lead Groups</h3>
            </div>
            <p className="text-3xl font-bold text-white">{leadGroups.length}</p>
            <p className="text-sm text-slate-400 mt-1">
              {leadGroups.reduce((sum, g) => sum + (g.total_leads || 0), 0)} total leads
            </p>
          </GlassCard>

          <GlassCard className="p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <Bot className="w-5 h-5 text-purple-400" />
              </div>
              <h3 className="font-semibold text-white">AI Agents</h3>
            </div>
            <p className="text-3xl font-bold text-white">{agents.length}</p>
            <p className="text-sm text-slate-400 mt-1">
              {agents.filter((a) => a.status === "active").length} active
            </p>
          </GlassCard>

          <GlassCard className="p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-emerald-500/10">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
              </div>
              <h3 className="font-semibold text-white">Campaigns</h3>
            </div>
            <p className="text-3xl font-bold text-white">{campaigns.length}</p>
            <p className="text-sm text-slate-400 mt-1">{activeCampaigns} running now</p>
          </GlassCard>
        </div>

        {/* Recent Activity */}
        <GlassCard className="p-6">
          <h3 className="font-semibold text-white text-lg mb-4">Recent Calls</h3>
          {callRecords.length === 0 ? (
            <div className="text-center py-8">
              <Phone className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-slate-400 text-sm">No calls yet. Start a campaign to see activity.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {callRecords.slice(0, 10).map((call) => (
                <div
                  key={call.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-slate-800/30 hover:bg-slate-800/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`p-2 rounded-lg ${
                        call.status === "completed"
                          ? "bg-emerald-500/10"
                          : call.status === "failed"
                          ? "bg-red-500/10"
                          : "bg-slate-700/50"
                      }`}
                    >
                      {call.status === "completed" ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : call.status === "failed" ? (
                        <XCircle className="w-4 h-4 text-red-400" />
                      ) : (
                        <Phone className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                    <div>
                      <p className="text-white font-medium text-sm">{call.lead_phone_number}</p>
                      <p className="text-xs text-slate-400">
                        {call.outcome || call.status || "Unknown"} • {call.duration_seconds || 0}s
                      </p>
                    </div>
                  </div>
                  <span className="text-xs text-slate-500">
                    {call.started_at ? format(new Date(call.started_at), "MMM d, h:mm a") : "—"}
                  </span>
                </div>
              ))}
            </div>
          )}
        </GlassCard>
      </div>
    </div>
  );
}