import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Header from "@/components/layout/Header";
import GlassCard from "@/components/ui/GlassCard";
import { User, LogOut } from "lucide-react";

export default function Settings() {
  const { data: user } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const handleLogout = () => {
    base44.auth.logout();
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Header title="Settings" subtitle="Manage your account and preferences" />

      <div className="p-8 space-y-6 max-w-2xl">
        <GlassCard className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20">
              <User className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <h3 className="font-semibold text-white text-lg">Profile</h3>
              <p className="text-sm text-slate-400">Your account information</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm text-slate-400 mb-1.5 block">Full Name</label>
              <Input
                value={user?.full_name || ""}
                disabled
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
            <div>
              <label className="text-sm text-slate-400 mb-1.5 block">Email</label>
              <Input
                value={user?.email || ""}
                disabled
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
            <div>
              <label className="text-sm text-slate-400 mb-1.5 block">Role</label>
              <Input
                value={user?.role || ""}
                disabled
                className="bg-slate-800/50 border-slate-700 text-white capitalize"
              />
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-6">
          <h3 className="font-semibold text-white text-lg mb-4">Account Actions</h3>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="border-red-500/50 text-red-400 hover:bg-red-500/10 hover:text-red-400"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </GlassCard>
      </div>
    </div>
  );
}