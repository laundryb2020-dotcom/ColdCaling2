import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Phone, Calendar, Play, X } from "lucide-react";
import Header from "@/components/layout/Header";
import GlassCard from "@/components/ui/GlassCard";
import StatusBadge from "@/components/ui/StatusBadge";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";

export default function CallLibrary() {
  const [selectedCall, setSelectedCall] = useState(null);
  const [callDetails, setCallDetails] = useState(null);
  const [loadingDetails, setLoadingDetails] = useState(false);

  const { data: callRecords = [], isLoading } = useQuery({
    queryKey: ["callRecords"],
    queryFn: () => base44.entities.CallRecord.list("-created_date", 100),
  });

  const handleSelectCall = async (call) => {
    setSelectedCall(call);
    setLoadingDetails(true);
    try {
      const response = await base44.functions.invoke('getVapiCallDetails', { 
        callRecordId: call.id 
      });
      setCallDetails(response.data);
    } catch (error) {
      console.error('Failed to fetch call details:', error);
      setCallDetails({
        transcript: call.transcript || '',
        recordingUrl: call.recording_url || '',
        summary: call.ai_summary || '',
        duration: call.duration_seconds || 0,
        sentiment: call.sentiment || null
      });
    } finally {
      setLoadingDetails(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Header title="Call Library" subtitle="Browse all call recordings and transcripts" />

      <div className="p-8 space-y-6">
        {isLoading ? (
          <div className="space-y-4">
            {Array(5)
              .fill(0)
              .map((_, i) => (
                <div key={i} className="h-24 bg-slate-800/50 rounded-2xl animate-pulse" />
              ))}
          </div>
        ) : callRecords.length === 0 ? (
          <GlassCard className="p-12 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center mx-auto mb-4">
              <Phone className="w-8 h-8 text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">No Call Records</h3>
            <p className="text-slate-400 text-sm">Start a campaign to see call records here.</p>
          </GlassCard>
        ) : (
          <div className="space-y-4">
            {callRecords.map((call, index) => (
              <GlassCard key={call.id} delay={index * 0.02} className="p-5 cursor-pointer hover:border-blue-500/50" onClick={() => handleSelectCall(call)}>
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    <div className="p-2.5 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20">
                      <Phone className="w-5 h-5 text-blue-400" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-white">{call.lead_phone_number}</h3>
                        <StatusBadge status={call.status} />
                        {call.outcome && <StatusBadge status={call.outcome} />}
                      </div>
                      {call.started_at && (
                        <div className="flex items-center gap-1.5 text-sm text-slate-400 mb-2">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{format(new Date(call.started_at), "MMM d, yyyy 'at' h:mm a")}</span>
                        </div>
                      )}
                      {call.transcript && (
                        <p className="text-sm text-slate-400 line-clamp-2">{call.transcript}</p>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-slate-400">Duration</p>
                    <p className="text-white font-medium">{call.duration_seconds || 0}s</p>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        )}
        </div>

        {/* Call Details Modal */}
        <Dialog open={!!selectedCall} onOpenChange={() => setSelectedCall(null)}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader className="flex flex-row items-center justify-between">
            <DialogTitle className="text-white">Call Details</DialogTitle>
            <DialogClose />
          </DialogHeader>

          {selectedCall && (
            <div className="space-y-6">
              {/* Header Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-slate-400 mb-1">Phone Number</p>
                  <p className="text-white font-semibold">{selectedCall.lead_phone_number}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-400 mb-1">Duration</p>
                  <p className="text-white font-semibold">{callDetails?.duration || selectedCall.duration_seconds || 0} seconds</p>
                </div>
                <div>
                  <p className="text-sm text-slate-400 mb-1">Status</p>
                  <StatusBadge status={selectedCall.status} />
                </div>
                <div>
                  <p className="text-sm text-slate-400 mb-1">Outcome</p>
                  {selectedCall.outcome ? <StatusBadge status={selectedCall.outcome} /> : <p className="text-slate-500">-</p>}
                </div>
              </div>

              {selectedCall.started_at && (
                <div>
                  <p className="text-sm text-slate-400 mb-1">Call Time</p>
                  <p className="text-white">{format(new Date(selectedCall.started_at), "MMM d, yyyy 'at' h:mm a")}</p>
                </div>
              )}

              {/* Recording Player */}
              {loadingDetails ? (
                <div className="animate-pulse h-12 bg-slate-800 rounded-lg" />
              ) : callDetails?.recordingUrl ? (
                <div>
                  <p className="text-sm text-slate-400 mb-2">Recording</p>
                  <audio controls className="w-full bg-slate-800 rounded-lg">
                    <source src={callDetails.recordingUrl} type="audio/mpeg" />
                    Your browser does not support the audio element.
                  </audio>
                </div>
              ) : (
                <div className="p-4 bg-slate-800/30 rounded-lg border border-slate-700">
                  <p className="text-sm text-slate-400">No recording available</p>
                </div>
              )}

              {/* Transcript */}
              {loadingDetails ? (
                <div className="animate-pulse h-32 bg-slate-800 rounded-lg" />
              ) : callDetails?.transcript ? (
                <div>
                  <p className="text-sm text-slate-400 mb-2">Transcript</p>
                  <div className="bg-slate-800/50 rounded-lg p-4 text-sm text-slate-300 max-h-96 overflow-y-auto space-y-2">
                    {typeof callDetails.transcript === 'string' ? (
                      <div className="whitespace-pre-wrap">{callDetails.transcript}</div>
                    ) : Array.isArray(callDetails.transcript) ? (
                      callDetails.transcript.map((msg, i) => (
                        <div key={i} className={msg.role === 'user' ? 'text-blue-300' : 'text-emerald-300'}>
                          <span className="font-semibold">{msg.role === 'user' ? 'Caller' : 'AI'}:</span> {msg.message}
                        </div>
                      ))
                    ) : typeof callDetails.transcript === 'object' ? (
                      <div className="space-y-2">
                        {callDetails.transcript.AI && (
                          <div className="text-emerald-300">
                            <span className="font-semibold">AI:</span> {Array.isArray(callDetails.transcript.AI) ? callDetails.transcript.AI.join(' ') : callDetails.transcript.AI}
                          </div>
                        )}
                        {callDetails.transcript.Caller && (
                          <div className="text-blue-300">
                            <span className="font-semibold">Caller:</span> {Array.isArray(callDetails.transcript.Caller) ? callDetails.transcript.Caller.join(' ') : callDetails.transcript.Caller}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div>{String(callDetails.transcript)}</div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-slate-800/30 rounded-lg border border-slate-700">
                  <p className="text-sm text-slate-400">No transcript available</p>
                </div>
              )}

              {/* AI Summary */}
              {callDetails?.summary && (
                <div>
                  <p className="text-sm text-slate-400 mb-2">AI Summary</p>
                  <div className="bg-slate-800/50 rounded-lg p-4 text-sm text-slate-300">
                    {callDetails.summary}
                  </div>
                </div>
              )}

              {/* Sentiment */}
              {callDetails?.sentiment && (
                <div>
                  <p className="text-sm text-slate-400 mb-1">Sentiment</p>
                  <p className="text-white font-semibold capitalize">{callDetails.sentiment}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
        </Dialog>
        </div>
        );
        }