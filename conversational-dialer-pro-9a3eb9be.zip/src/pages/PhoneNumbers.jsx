import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Plus, Phone, MoreVertical, Trash2, CheckCircle2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Header from "@/components/layout/Header";
import GlassCard from "@/components/ui/GlassCard";
import StatsCard from "@/components/ui/StatsCard";
import StatusBadge from "@/components/ui/StatusBadge";

export default function PhoneNumbers() {
  const urlParams = new URLSearchParams(window.location.search);
  const actionParam = urlParams.get("action");

  const [showBuyDialog, setShowBuyDialog] = useState(actionParam === "buy");
  const [searchAreaCode, setSearchAreaCode] = useState("");
  const [selectedNumber, setSelectedNumber] = useState(null);
  const [availableNumbers, setAvailableNumbers] = useState([]);
  const [searchingNumbers, setSearchingNumbers] = useState(false);

  const queryClient = useQueryClient();

  const { data: phoneNumbers = [], isLoading } = useQuery({
    queryKey: ["phoneNumbers"],
    queryFn: () => base44.entities.PhoneNumber.list("-created_date"),
  });

  const searchNumbers = async () => {
    setSearchingNumbers(true);
    try {
      const response = await base44.functions.invoke('searchTwilioNumbers', { 
        areaCode: searchAreaCode 
      });
      setAvailableNumbers(response.data.numbers || []);
    } catch (error) {
      console.error('Failed to search numbers:', error);
      setAvailableNumbers([]);
    } finally {
      setSearchingNumbers(false);
    }
  };

  const buyNumberMutation = useMutation({
    mutationFn: async (numberData) => {
      // Purchase from Vapi
      const vapiResponse = await base44.functions.invoke('buyTwilioNumber', { 
        phoneNumber: numberData.number,
        areaCode: numberData.area_code
      });
      
      // Save to database with Vapi ID
      return base44.entities.PhoneNumber.create({
        ...numberData,
        metadata: {
          vapi_phone_number_id: vapiResponse.data.vapiPhoneId
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["phoneNumbers"]);
      setShowBuyDialog(false);
      setSelectedNumber(null);
    },
  });

  const updateNumberMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PhoneNumber.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(["phoneNumbers"]);
    },
  });

  const deleteNumberMutation = useMutation({
    mutationFn: (id) => base44.entities.PhoneNumber.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(["phoneNumbers"]);
    },
  });

  const handleBuyNumber = () => {
    if (!selectedNumber) return;
    buyNumberMutation.mutate({
      number: selectedNumber.number,
      friendly_name: `${selectedNumber.region} Number`,
      area_code: selectedNumber.area_code,
      region: selectedNumber.region,
      country: "US",
      status: "active",
      monthly_cost: 1.0,
    });
  };

  const toggleNumberStatus = (number) => {
    const newStatus = number.status === "active" ? "inactive" : "active";
    updateNumberMutation.mutate({
      id: number.id,
      data: { ...number, status: newStatus },
    });
  };

  const activeNumbers = phoneNumbers.filter((n) => n.status === "active").length;
  const totalCost = phoneNumbers.reduce((sum, n) => sum + (n.monthly_cost || 0), 0);

  return (
    <div className="min-h-screen bg-slate-950">
      <Header title="Phone Numbers" subtitle="Manage your calling numbers" />

      <div className="p-8 space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <StatsCard title="Total Numbers" value={phoneNumbers.length} subtitle="Owned numbers" icon={Phone} />
          <StatsCard title="Active Lines" value={activeNumbers} subtitle="Currently active" icon={CheckCircle2} />
          <StatsCard title="Monthly Cost" value={`$${totalCost.toFixed(2)}`} subtitle="Total per month" icon={Phone} />
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-white">Your Phone Numbers</h2>
          <Button
            onClick={() => setShowBuyDialog(true)}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
          >
            <Plus className="w-4 h-4 mr-2" />
            Buy Number
          </Button>
        </div>

        {/* Numbers List */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Array(4)
              .fill(0)
              .map((_, i) => (
                <div key={i} className="h-32 bg-slate-800/50 rounded-2xl animate-pulse" />
              ))}
          </div>
        ) : phoneNumbers.length === 0 ? (
          <GlassCard className="p-12 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center mx-auto mb-4">
              <Phone className="w-8 h-8 text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">No Phone Numbers</h3>
            <p className="text-slate-400 text-sm mb-6 max-w-sm mx-auto">
              Purchase phone numbers to start making outbound calls to your leads.
            </p>
            <Button
              onClick={() => setShowBuyDialog(true)}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
            >
              <Plus className="w-4 h-4 mr-2" />
              Buy First Number
            </Button>
          </GlassCard>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {phoneNumbers.map((number, index) => (
              <GlassCard key={number.id} delay={index * 0.05} className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20">
                      <Phone className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-white text-lg">{number.number}</h3>
                      <p className="text-sm text-slate-400">{number.region}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusBadge status={number.status} />
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                        <DropdownMenuItem
                          onClick={() => toggleNumberStatus(number)}
                          className="text-slate-300 focus:text-white focus:bg-slate-800"
                        >
                          {number.status === "active" ? (
                            <>
                              <XCircle className="w-4 h-4 mr-2" />
                              Deactivate
                            </>
                          ) : (
                            <>
                              <CheckCircle2 className="w-4 h-4 mr-2" />
                              Activate
                            </>
                          )}
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => deleteNumberMutation.mutate(number.id)}
                          className="text-red-400 focus:text-red-400 focus:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Release
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-500">Area Code: {number.area_code}</span>
                  <span className="text-slate-500">${number.monthly_cost || "1.00"}/mo</span>
                </div>
              </GlassCard>
            ))}
          </div>
        )}
      </div>

      {/* Buy Number Dialog */}
      <Dialog open={showBuyDialog} onOpenChange={setShowBuyDialog}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Buy Phone Number</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="e.g., 415, 310, 212"
                value={searchAreaCode}
                onChange={(e) => setSearchAreaCode(e.target.value)}
                className="flex-1 bg-slate-800/50 border-slate-700 text-white"
              />
              <Button
                onClick={searchNumbers}
                disabled={searchingNumbers}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
              >
                {searchingNumbers ? "Searching..." : "Search"}
              </Button>
            </div>

            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {searchingNumbers ? (
                <div className="text-center py-8 text-slate-400">Searching for numbers...</div>
              ) : availableNumbers.length === 0 ? (
                <div className="text-center py-8 text-slate-400">
                  Click "Search" to find available phone numbers
                </div>
              ) : (
                <>
                  <p className="text-sm text-slate-400 mb-3">Available Numbers:</p>
                  {availableNumbers.map((number) => (
                <div
                  key={number.number}
                  onClick={() => setSelectedNumber(number)}
                  className={`p-4 rounded-lg border cursor-pointer transition-all ${
                    selectedNumber?.number === number.number
                      ? "bg-blue-500/10 border-blue-500/50"
                      : "bg-slate-800/50 border-slate-700/50 hover:border-slate-600/50"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-mono text-white font-medium">{number.number}</p>
                      <p className="text-sm text-slate-400">{number.region}</p>
                    </div>
                    <span className="text-sm text-slate-500">$1.00/mo</span>
                  </div>
                </div>
              ))}
                </>
              )}
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <Button
              variant="outline"
              className="flex-1 border-slate-700 text-slate-300 hover:bg-slate-800"
              onClick={() => {
                setShowBuyDialog(false);
                setSelectedNumber(null);
              }}
            >
              Cancel
            </Button>
            <Button
              className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
              onClick={handleBuyNumber}
              disabled={!selectedNumber || buyNumberMutation.isPending}
            >
              {buyNumberMutation.isPending ? "Purchasing..." : "Purchase Number"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}