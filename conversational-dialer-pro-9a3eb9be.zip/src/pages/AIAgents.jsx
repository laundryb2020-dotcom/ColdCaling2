import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Plus, Bot, MoreVertical, Edit, Trash2, Play, Pause } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import Header from "@/components/layout/Header";
import GlassCard from "@/components/ui/GlassCard";
import StatusBadge from "@/components/ui/StatusBadge";

const defaultAgent = {
  name: "",
  persona: "",
  voice_gender: "female",
  voice_pitch: 0,
  voice_speed: 1.0,
  instructions: "",
  greeting: "",
  status: "draft",
};

export default function AIAgents() {
  const urlParams = new URLSearchParams(window.location.search);
  const actionParam = urlParams.get("action");

  const [showDialog, setShowDialog] = useState(actionParam === "new");
  const [editingAgent, setEditingAgent] = useState(null);
  const [formData, setFormData] = useState(defaultAgent);

  const queryClient = useQueryClient();

  const { data: agents = [], isLoading } = useQuery({
    queryKey: ["agents"],
    queryFn: () => base44.entities.AIAgent.list("-created_date"),
  });

  const createAgentMutation = useMutation({
    mutationFn: (data) => base44.entities.AIAgent.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["agents"]);
      closeDialog();
    },
  });

  const updateAgentMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.AIAgent.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(["agents"]);
      closeDialog();
    },
  });

  const deleteAgentMutation = useMutation({
    mutationFn: (id) => base44.entities.AIAgent.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(["agents"]);
    },
  });

  const openNewDialog = () => {
    setEditingAgent(null);
    setFormData(defaultAgent);
    setShowDialog(true);
  };

  const openEditDialog = (agent) => {
    setEditingAgent(agent);
    setFormData({
      name: agent.name || "",
      persona: agent.persona || "",
      voice_gender: agent.voice_gender || "female",
      voice_pitch: agent.voice_pitch || 0,
      voice_speed: agent.voice_speed || 1.0,
      instructions: agent.instructions || "",
      greeting: agent.greeting || "",
      status: agent.status || "draft",
    });
    setShowDialog(true);
  };

  const closeDialog = () => {
    setShowDialog(false);
    setEditingAgent(null);
    setFormData(defaultAgent);
  };

  const handleSave = () => {
    if (!formData.name.trim() || !formData.instructions.trim()) return;

    if (editingAgent) {
      updateAgentMutation.mutate({ id: editingAgent.id, data: formData });
    } else {
      createAgentMutation.mutate(formData);
    }
  };

  const toggleAgentStatus = (agent) => {
    const newStatus = agent.status === "active" ? "inactive" : "active";
    updateAgentMutation.mutate({
      id: agent.id,
      data: { ...agent, status: newStatus },
    });
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Header title="AI Agents" subtitle="Create and manage your conversational AI agents" />

      <div className="p-8 space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-white">Your AI Agents</h2>
          <Button
            onClick={openNewDialog}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Agent
          </Button>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array(6)
              .fill(0)
              .map((_, i) => (
                <div key={i} className="h-48 bg-slate-800/50 rounded-2xl animate-pulse" />
              ))}
          </div>
        ) : agents.length === 0 ? (
          <GlassCard className="p-12 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center mx-auto mb-4">
              <Bot className="w-8 h-8 text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">No AI Agents</h3>
            <p className="text-slate-400 text-sm mb-6 max-w-sm mx-auto">
              Create your first AI agent to handle conversations with your leads.
            </p>
            <Button
              onClick={openNewDialog}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create AI Agent
            </Button>
          </GlassCard>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {agents.map((agent, index) => (
              <GlassCard key={agent.id} delay={index * 0.05} className="p-5">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20">
                      <Bot className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-white text-lg">{agent.name}</h3>
                      <StatusBadge status={agent.status} />
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                      <DropdownMenuItem
                        onClick={() => toggleAgentStatus(agent)}
                        className="text-slate-300 focus:text-white focus:bg-slate-800"
                      >
                        {agent.status === "active" ? (
                          <>
                            <Pause className="w-4 h-4 mr-2" />
                            Deactivate
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            Activate
                          </>
                        )}
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => openEditDialog(agent)}
                        className="text-slate-300 focus:text-white focus:bg-slate-800"
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => deleteAgentMutation.mutate(agent.id)}
                        className="text-red-400 focus:text-red-400 focus:bg-red-500/10"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {agent.persona && <p className="text-sm text-slate-400 mb-3">{agent.persona}</p>}

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Voice</span>
                    <span className="text-white capitalize">{agent.voice_gender}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Speed</span>
                    <span className="text-white">{agent.voice_speed || 1.0}x</span>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        )}
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={showDialog} onOpenChange={closeDialog}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingAgent ? "Edit AI Agent" : "Create AI Agent"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <label className="text-sm text-slate-400 mb-1.5 block">Agent Name</label>
              <Input
                placeholder="e.g., Sales Assistant"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>

            <div>
              <label className="text-sm text-slate-400 mb-1.5 block">Persona</label>
              <Input
                placeholder="e.g., Professional Sales Executive"
                value={formData.persona}
                onChange={(e) => setFormData({ ...formData, persona: e.target.value })}
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>

            <div>
              <label className="text-sm text-slate-400 mb-1.5 block">Instructions</label>
              <Textarea
                placeholder="Define the agent's behavior, goals, and conversation flow..."
                value={formData.instructions}
                onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
                className="bg-slate-800/50 border-slate-700 text-white resize-none"
                rows={6}
              />
            </div>

            <div>
              <label className="text-sm text-slate-400 mb-1.5 block">Greeting</label>
              <Input
                placeholder="e.g., Hi, this is Sarah calling from..."
                value={formData.greeting}
                onChange={(e) => setFormData({ ...formData, greeting: e.target.value })}
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-slate-400 mb-1.5 block">Voice Gender</label>
                <Select
                  value={formData.voice_gender}
                  onValueChange={(value) => setFormData({ ...formData, voice_gender: value })}
                >
                  <SelectTrigger className="bg-slate-800/50 border-slate-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-800">
                    <SelectItem value="female" className="text-slate-300">
                      Female
                    </SelectItem>
                    <SelectItem value="male" className="text-slate-300">
                      Male
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-slate-400 mb-1.5 block">
                  Voice Speed: {formData.voice_speed}x
                </label>
                <Slider
                  value={[formData.voice_speed]}
                  onValueChange={(v) => setFormData({ ...formData, voice_speed: v[0] })}
                  min={0.5}
                  max={2.0}
                  step={0.1}
                  className="mt-2"
                />
              </div>
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <Button
              variant="outline"
              className="flex-1 border-slate-700 text-slate-300 hover:bg-slate-800"
              onClick={closeDialog}
            >
              Cancel
            </Button>
            <Button
              className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-0"
              onClick={handleSave}
              disabled={!formData.name.trim() || !formData.instructions.trim()}
            >
              {editingAgent ? "Save Changes" : "Create Agent"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}