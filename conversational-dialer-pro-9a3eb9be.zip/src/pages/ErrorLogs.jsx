import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/Header";
import GlassCard from "@/components/ui/GlassCard";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertCircle, RefreshCw, Trash2 } from "lucide-react";
import { format } from "date-fns";

export default function ErrorLogs() {
  const [selectedError, setSelectedError] = useState(null);

  const { data: errors, isLoading, refetch } = useQuery({
    queryKey: ['errorLogs'],
    queryFn: () => base44.entities.ErrorLog.list('-created_date', 100),
    initialData: []
  });

  const handleClearAll = async () => {
    if (!confirm('Clear all error logs?')) return;
    
    for (const error of errors) {
      await base44.entities.ErrorLog.delete(error.id);
    }
    refetch();
  };

  const errorTypeColors = {
    'Twilio API Error': 'bg-red-500/10 text-red-500',
    'Call Initiation Error': 'bg-orange-500/10 text-orange-500',
    'Campaign Processing Error': 'bg-yellow-500/10 text-yellow-500',
    'Webhook Processing Error': 'bg-purple-500/10 text-purple-500',
    'TwiML Generation Error': 'bg-pink-500/10 text-pink-500'
  };

  return (
    <div className="p-6">
      <Header
        title="Error Logs"
        subtitle="Monitor Twilio integration errors"
        actions={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => refetch()}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
            <Button variant="destructive" onClick={handleClearAll}>
              <Trash2 className="w-4 h-4 mr-2" />
              Clear All
            </Button>
          </div>
        }
      />

      <div className="max-w-7xl mx-auto mt-6">
        {isLoading ? (
          <GlassCard className="p-6">
            <p className="text-slate-400">Loading errors...</p>
          </GlassCard>
        ) : errors.length === 0 ? (
          <GlassCard className="p-12 text-center">
            <AlertCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-200 mb-2">No Errors</h3>
            <p className="text-slate-400">All systems running smoothly!</p>
          </GlassCard>
        ) : (
          <div className="grid gap-4">
            {errors.map((error) => (
              <GlassCard 
                key={error.id} 
                className="p-4 cursor-pointer hover:bg-white/5 transition-colors"
                onClick={() => setSelectedError(selectedError?.id === error.id ? null : error)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <AlertCircle className="w-5 h-5 text-red-400" />
                      <Badge className={errorTypeColors[error.error_type] || 'bg-slate-500/10 text-slate-400'}>
                        {error.error_type}
                      </Badge>
                      <Badge variant="outline" className="text-slate-400">
                        {error.source}
                      </Badge>
                      <span className="text-xs text-slate-500">
                        {format(new Date(error.created_date), 'MMM d, yyyy HH:mm:ss')}
                      </span>
                    </div>
                    
                    <p className="text-slate-300 mb-2">{error.error_message}</p>

                    {selectedError?.id === error.id && (
                      <div className="mt-4 space-y-3">
                        {error.context && (
                          <div>
                            <h4 className="text-sm font-semibold text-slate-400 mb-1">Context:</h4>
                            <pre className="bg-slate-900/50 p-3 rounded text-xs text-slate-300 overflow-x-auto">
                              {JSON.stringify(error.context, null, 2)}
                            </pre>
                          </div>
                        )}
                        
                        {error.twilio_response && (
                          <div>
                            <h4 className="text-sm font-semibold text-slate-400 mb-1">Twilio Response:</h4>
                            <pre className="bg-slate-900/50 p-3 rounded text-xs text-slate-300 overflow-x-auto">
                              {error.twilio_response}
                            </pre>
                          </div>
                        )}
                        
                        {error.stack_trace && (
                          <div>
                            <h4 className="text-sm font-semibold text-slate-400 mb-1">Stack Trace:</h4>
                            <pre className="bg-slate-900/50 p-3 rounded text-xs text-slate-300 overflow-x-auto max-h-48">
                              {error.stack_trace}
                            </pre>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      base44.entities.ErrorLog.delete(error.id).then(refetch);
                    }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </GlassCard>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}