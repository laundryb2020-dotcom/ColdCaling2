import { Phone, UserCheck, Clock, TrendingUp } from "lucide-react";
import StatsCard from "@/components/ui/StatsCard";

export default function QuickStats({ campaigns = [], callRecords = [], leads = [] }) {
  // Calculate total stats across all campaigns
  const totalCalls = callRecords.length;
  const answeredCalls = callRecords.filter(c => c.status === "completed").length;
  const qualifiedLeads = leads.filter(l => l.status === "qualified").length;
  const activeCampaigns = campaigns.filter(c => c.status === "running").length;
  
  // Calculate answer rate
  const answerRate = totalCalls > 0 ? Math.round((answeredCalls / totalCalls) * 100) : 0;
  
  // Calculate qualification rate
  const qualificationRate = answeredCalls > 0 ? Math.round((qualifiedLeads / answeredCalls) * 100) : 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatsCard
        title="Total Calls Today"
        value={totalCalls.toLocaleString()}
        icon={Phone}
        trend="+12%"
        trendDirection="up"
        iconClassName="from-blue-500/20 to-blue-600/10"
        delay={0}
      />
      <StatsCard
        title="Answer Rate"
        value={`${answerRate}%`}
        icon={TrendingUp}
        trend="+5%"
        trendDirection="up"
        iconClassName="from-emerald-500/20 to-emerald-600/10"
        delay={0.1}
      />
      <StatsCard
        title="Qualified Leads"
        value={qualifiedLeads.toLocaleString()}
        icon={UserCheck}
        trend="+8%"
        trendDirection="up"
        iconClassName="from-green-500/20 to-green-600/10"
        delay={0.2}
      />
      <StatsCard
        title="Active Campaigns"
        value={activeCampaigns.toString()}
        icon={Clock}
        subtitle={`${campaigns.length} total campaigns`}
        iconClassName="from-purple-500/20 to-purple-600/10"
        delay={0.3}
      />
    </div>
  );
}