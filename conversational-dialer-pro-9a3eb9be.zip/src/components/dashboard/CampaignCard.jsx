import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Play, Pause, Users, Phone, Clock, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import GlassCard from "@/components/ui/GlassCard";
import StatusBadge from "@/components/ui/StatusBadge";
import { cn } from "@/lib/utils";

export default function CampaignCard({ campaign, leadGroup, agent, delay = 0 }) {
  const stats = campaign.stats || {};
  const totalCalls = stats.total_calls || 0;
  const totalLeads = leadGroup?.total_leads || 0;
  const progress = totalLeads > 0 ? Math.round((totalCalls / totalLeads) * 100) : 0;
  const answerRate = totalCalls > 0 ? Math.round((stats.answered / totalCalls) * 100) : 0;

  return (
    <GlassCard delay={delay} className="p-5">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="font-semibold text-white text-lg">{campaign.name}</h3>
          <p className="text-sm text-slate-400 mt-0.5 line-clamp-1">{campaign.description || "No description"}</p>
        </div>
        <StatusBadge status={campaign.status} />
      </div>

      {/* Progress */}
      <div className="mb-4">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
          <span>Progress</span>
          <span className="text-white font-medium">{progress}%</span>
        </div>
        <Progress 
          value={progress} 
          className="h-1.5 bg-slate-800"
        />
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-4 gap-3 mb-4">
        <div className="text-center">
          <p className="text-lg font-bold text-white">{totalCalls}</p>
          <p className="text-xs text-slate-500">Calls</p>
        </div>
        <div className="text-center">
          <p className="text-lg font-bold text-emerald-400">{stats.answered || 0}</p>
          <p className="text-xs text-slate-500">Answered</p>
        </div>
        <div className="text-center">
          <p className="text-lg font-bold text-green-400">{stats.qualified || 0}</p>
          <p className="text-xs text-slate-500">Qualified</p>
        </div>
        <div className="text-center">
          <p className="text-lg font-bold text-slate-400">{stats.no_answer || 0}</p>
          <p className="text-xs text-slate-500">No Answer</p>
        </div>
      </div>

      {/* Meta Info */}
      <div className="flex items-center gap-4 text-xs text-slate-500 mb-4 pb-4 border-b border-slate-800/50">
        <div className="flex items-center gap-1.5">
          <Users className="w-3.5 h-3.5" />
          <span>{leadGroup?.name || "Unknown Group"}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <TrendingUp className="w-3.5 h-3.5" />
          <span>{answerRate}% answer rate</span>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        {campaign.status === "running" ? (
          <Button 
            size="sm" 
            variant="outline" 
            className="flex-1 border-amber-500/30 text-amber-400 hover:bg-amber-500/10"
          >
            <Pause className="w-4 h-4 mr-2" />
            Pause
          </Button>
        ) : (
          <Button 
            size="sm" 
            className="flex-1 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white border-0"
          >
            <Play className="w-4 h-4 mr-2" />
            {campaign.status === "paused" ? "Resume" : "Start"}
          </Button>
        )}
        <Button 
          size="sm" 
          variant="outline" 
          className="border-slate-700 text-slate-300 hover:bg-slate-800"
          asChild
        >
          <Link to={createPageUrl("CampaignDetail") + `?id=${campaign.id}`}>
            View
          </Link>
        </Button>
      </div>
    </GlassCard>
  );
}