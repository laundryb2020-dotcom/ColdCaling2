import { Phone, PhoneOff, UserCheck, UserX, Clock, VoicemailIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import GlassCard from "@/components/ui/GlassCard";
import { format } from "date-fns";

const activityIcons = {
  answered: { icon: Phone, color: "text-emerald-400", bg: "bg-emerald-500/10" },
  qualified: { icon: UserCheck, color: "text-green-400", bg: "bg-green-500/10" },
  disqualified: { icon: UserX, color: "text-red-400", bg: "bg-red-500/10" },
  no_answer: { icon: PhoneOff, color: "text-slate-400", bg: "bg-slate-500/10" },
  voicemail: { icon: VoicemailIcon, color: "text-purple-400", bg: "bg-purple-500/10" },
  callback: { icon: Clock, color: "text-cyan-400", bg: "bg-cyan-500/10" },
};

export default function ActivityFeed({ activities = [] }) {
  if (activities.length === 0) {
    return (
      <GlassCard className="p-6">
        <h3 className="font-semibold text-white mb-4">Recent Activity</h3>
        <div className="text-center py-8">
          <Phone className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <p className="text-slate-400 text-sm">No recent activity</p>
          <p className="text-slate-500 text-xs mt-1">Start a campaign to see calls here</p>
        </div>
      </GlassCard>
    );
  }

  return (
    <GlassCard className="p-6">
      <h3 className="font-semibold text-white mb-4">Recent Activity</h3>
      <div className="space-y-3">
        {activities.map((activity, index) => {
          const config = activityIcons[activity.outcome] || activityIcons.no_answer;
          const Icon = config.icon;
          
          return (
            <div 
              key={activity.id || index}
              className="flex items-start gap-3 p-3 rounded-xl bg-slate-800/30 hover:bg-slate-800/50 transition-colors"
            >
              <div className={cn("p-2 rounded-lg", config.bg)}>
                <Icon className={cn("w-4 h-4", config.color)} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white font-medium truncate">
                  {activity.lead_phone_number}
                </p>
                <p className="text-xs text-slate-400 mt-0.5">
                  {activity.outcome?.replace(/_/g, " ")} • {activity.duration_seconds || 0}s
                </p>
              </div>
              <span className="text-xs text-slate-500 whitespace-nowrap">
                {activity.ended_at ? format(new Date(activity.ended_at), "HH:mm") : "--:--"}
              </span>
            </div>
          );
        })}
      </div>
    </GlassCard>
  );
}