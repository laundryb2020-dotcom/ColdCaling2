import { useState } from "react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Search, 
  MoreVertical, 
  Phone, 
  Edit, 
  Trash2, 
  Filter,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import StatusBadge from "@/components/ui/StatusBadge";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

const ITEMS_PER_PAGE = 10;

export default function LeadTable({ 
  leads = [], 
  onEdit, 
  onDelete,
  onCall,
  isLoading = false 
}) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);

  // Filter leads
  const filteredLeads = leads.filter(lead => {
    const matchesSearch = 
      lead.first_name?.toLowerCase().includes(search.toLowerCase()) ||
      lead.last_name?.toLowerCase().includes(search.toLowerCase()) ||
      lead.phone_number?.includes(search) ||
      lead.email?.toLowerCase().includes(search.toLowerCase()) ||
      lead.company?.toLowerCase().includes(search.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || lead.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  // Pagination
  const totalPages = Math.ceil(filteredLeads.length / ITEMS_PER_PAGE);
  const paginatedLeads = filteredLeads.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const statuses = ["all", "new", "dialing", "answered", "qualified", "disqualified", "no_answer", "voicemail", "callback"];

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <Input
            placeholder="Search leads..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
            className="pl-10 bg-slate-900/50 border-slate-800 text-slate-300 placeholder:text-slate-500"
          />
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800">
              <Filter className="w-4 h-4 mr-2" />
              {statusFilter === "all" ? "All Status" : statusFilter.replace(/_/g, " ")}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-slate-900 border-slate-800">
            {statuses.map(status => (
              <DropdownMenuItem
                key={status}
                onClick={() => { setStatusFilter(status); setCurrentPage(1); }}
                className={cn(
                  "text-slate-300 focus:text-white focus:bg-slate-800 capitalize",
                  status === statusFilter && "bg-slate-800"
                )}
              >
                {status.replace(/_/g, " ")}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
        
        <span className="text-sm text-slate-500">
          {filteredLeads.length} leads
        </span>
      </div>

      {/* Table */}
      <div className="rounded-xl border border-slate-800/50 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="border-slate-800/50 hover:bg-transparent">
              <TableHead className="text-slate-400">Name</TableHead>
              <TableHead className="text-slate-400">Phone</TableHead>
              <TableHead className="text-slate-400">Email</TableHead>
              <TableHead className="text-slate-400">Company</TableHead>
              <TableHead className="text-slate-400">Status</TableHead>
              <TableHead className="text-slate-400">Attempts</TableHead>
              <TableHead className="text-slate-400 w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array(5).fill(0).map((_, i) => (
                <TableRow key={i} className="border-slate-800/50">
                  <TableCell colSpan={7}>
                    <div className="h-10 bg-slate-800/50 rounded animate-pulse" />
                  </TableCell>
                </TableRow>
              ))
            ) : paginatedLeads.length === 0 ? (
              <TableRow className="border-slate-800/50">
                <TableCell colSpan={7} className="text-center py-8 text-slate-500">
                  No leads found
                </TableCell>
              </TableRow>
            ) : (
              paginatedLeads.map((lead) => (
                <TableRow 
                  key={lead.id} 
                  className="border-slate-800/50 hover:bg-slate-800/30 transition-colors"
                >
                  <TableCell>
                    <div>
                      <p className="text-white font-medium">
                        {lead.first_name || lead.last_name 
                          ? `${lead.first_name || ""} ${lead.last_name || ""}`.trim()
                          : "Unknown"
                        }
                      </p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="text-slate-300 font-mono text-sm">
                      {lead.phone_number}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className="text-slate-400 text-sm">
                      {lead.email || "—"}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className="text-slate-400 text-sm">
                      {lead.company || "—"}
                    </span>
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={lead.status} />
                  </TableCell>
                  <TableCell>
                    <span className="text-slate-400 text-sm">
                      {lead.call_attempts || 0}
                    </span>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-slate-400 hover:text-white hover:bg-slate-800"
                        >
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                        <DropdownMenuItem 
                          onClick={() => onCall?.(lead)}
                          className="text-slate-300 focus:text-white focus:bg-slate-800"
                        >
                          <Phone className="w-4 h-4 mr-2" />
                          Call Now
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => onEdit?.(lead)}
                          className="text-slate-300 focus:text-white focus:bg-slate-800"
                        >
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => onDelete?.(lead)}
                          className="text-red-400 focus:text-red-400 focus:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <span className="text-sm text-slate-500">
            Page {currentPage} of {totalPages}
          </span>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="border-slate-700 text-slate-300 hover:bg-slate-800 disabled:opacity-50"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="border-slate-700 text-slate-300 hover:bg-slate-800 disabled:opacity-50"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}