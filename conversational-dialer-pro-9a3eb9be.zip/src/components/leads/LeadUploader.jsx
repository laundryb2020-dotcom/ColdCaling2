import { useState, useCallback } from "react";
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle, X, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";

// E.164 phone number validation
function validateE164(phone) {
  const cleaned = phone.replace(/[\s\-\(\)\.]/g, "");
  if (/^\+?1?\d{10,14}$/.test(cleaned)) {
    if (cleaned.startsWith("+")) return cleaned;
    if (cleaned.length === 10) return `+1${cleaned}`;
    if (cleaned.length === 11 && cleaned.startsWith("1")) return `+${cleaned}`;
    return `+${cleaned}`;
  }
  return null;
}

function parseCSV(text) {
  const lines = text.trim().split(/\r?\n/);
  if (lines.length < 2) return { headers: [], rows: [] };
  
  const headers = lines[0].split(",").map(h => h.trim().toLowerCase().replace(/['"]/g, ""));
  const rows = lines.slice(1).map(line => {
    const values = line.split(",").map(v => v.trim().replace(/['"]/g, ""));
    const row = {};
    headers.forEach((h, i) => {
      row[h] = values[i] || "";
    });
    return row;
  });
  
  return { headers, rows };
}

function mapToLead(row, mapping) {
  const lead = {};
  
  // Phone number (required)
  const phoneField = mapping.phone || Object.keys(row).find(k => 
    k.includes("phone") || k.includes("mobile") || k.includes("cell") || k.includes("number")
  );
  if (phoneField && row[phoneField]) {
    lead.phone_number = validateE164(row[phoneField]);
  }
  
  // First name
  const firstNameField = mapping.first_name || Object.keys(row).find(k => 
    k.includes("first") || k === "fname" || k === "name"
  );
  if (firstNameField) lead.first_name = row[firstNameField];
  
  // Last name
  const lastNameField = mapping.last_name || Object.keys(row).find(k => 
    k.includes("last") || k === "lname" || k === "surname"
  );
  if (lastNameField) lead.last_name = row[lastNameField];
  
  // Email
  const emailField = mapping.email || Object.keys(row).find(k => 
    k.includes("email") || k.includes("mail")
  );
  if (emailField) lead.email = row[emailField];
  
  // Company
  const companyField = mapping.company || Object.keys(row).find(k => 
    k.includes("company") || k.includes("business") || k.includes("organization")
  );
  if (companyField) lead.company = row[companyField];
  
  // Store unmapped fields in custom_fields
  const mappedFields = [phoneField, firstNameField, lastNameField, emailField, companyField].filter(Boolean);
  const customFields = {};
  Object.keys(row).forEach(key => {
    if (!mappedFields.includes(key) && row[key]) {
      customFields[key] = row[key];
    }
  });
  if (Object.keys(customFields).length > 0) {
    lead.custom_fields = customFields;
  }
  
  return lead;
}

export default function LeadUploader({ onComplete, onCancel, isLoading }) {
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState(null);
  const [parseResult, setParseResult] = useState(null);
  const [validationResult, setValidationResult] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const processFile = useCallback(async (file) => {
    setFile(file);
    setIsProcessing(true);
    
    try {
      const text = await file.text();
      const { headers, rows } = parseCSV(text);
      
      if (rows.length === 0) {
        setParseResult({ error: "No data rows found in the file" });
        return;
      }
      
      // Map and validate leads
      const leads = rows.map(row => mapToLead(row, {}));
      const validLeads = leads.filter(l => l.phone_number);
      const invalidLeads = leads.filter(l => !l.phone_number);
      
      setParseResult({ headers, totalRows: rows.length });
      setValidationResult({
        valid: validLeads,
        invalid: invalidLeads,
        validCount: validLeads.length,
        invalidCount: invalidLeads.length
      });
    } catch (error) {
      setParseResult({ error: "Failed to parse file: " + error.message });
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFile = e.dataTransfer?.files?.[0];
    if (droppedFile && (droppedFile.name.endsWith(".csv") || droppedFile.name.endsWith(".txt"))) {
      processFile(droppedFile);
    }
  }, [processFile]);

  const handleFileSelect = (e) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      processFile(selectedFile);
    }
  };

  const handleUpload = async () => {
    if (!validationResult?.valid?.length) return;
    
    setIsProcessing(true);
    setUploadProgress(0);
    
    const leadsToImport = validationResult.valid.map(lead => ({
      ...lead,
      status: "new"
    }));
    
    // Simulate progress for visual feedback
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => Math.min(prev + 10, 90));
    }, 100);
    
    try {
      await onComplete(leadsToImport);
      setUploadProgress(100);
      
      // Reset after success
      setTimeout(() => {
        setFile(null);
        setParseResult(null);
        setValidationResult(null);
        setUploadProgress(0);
      }, 1000);
    } finally {
      clearInterval(progressInterval);
      setIsProcessing(false);
    }
  };

  const reset = () => {
    setFile(null);
    setParseResult(null);
    setValidationResult(null);
    setUploadProgress(0);
  };

  const downloadTemplate = async () => {
    const response = await base44.functions.invoke('downloadLeadTemplate');
    const blob = new Blob([response.data], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'lead_upload_template.csv';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button
          variant="outline"
          size="sm"
          onClick={downloadTemplate}
          className="border-slate-700 text-slate-300 hover:bg-slate-800"
        >
          <Download className="w-4 h-4 mr-2" />
          Download Template
        </Button>
      </div>
      <AnimatePresence mode="wait">
        {!file ? (
          <motion.div
            key="dropzone"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            className={cn(
              "border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200",
              isDragging 
                ? "border-blue-500 bg-blue-500/10" 
                : "border-slate-700 hover:border-slate-600 bg-slate-800/30"
            )}
          >
            <input
              type="file"
              accept=".csv,.txt"
              onChange={handleFileSelect}
              className="hidden"
              id="file-upload"
            />
            <label htmlFor="file-upload" className="cursor-pointer">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center mx-auto mb-4">
                <Upload className="w-7 h-7 text-blue-400" />
              </div>
              <p className="text-white font-medium mb-1">
                Drop your CSV file here or click to browse
              </p>
              <p className="text-sm text-slate-400">
                Supports CSV files with phone numbers
              </p>
            </label>
          </motion.div>
        ) : (
          <motion.div
            key="preview"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="rounded-xl bg-slate-800/50 border border-slate-700/50 p-5"
          >
            {/* File Info */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-emerald-500/10">
                  <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <p className="text-white font-medium">{file.name}</p>
                  <p className="text-xs text-slate-400">
                    {(file.size / 1024).toFixed(1)} KB
                  </p>
                </div>
              </div>
              <Button
                size="icon"
                variant="ghost"
                className="text-slate-400 hover:text-white"
                onClick={reset}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>

            {parseResult?.error ? (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                <AlertCircle className="w-4 h-4 text-red-400" />
                <p className="text-sm text-red-400">{parseResult.error}</p>
              </div>
            ) : validationResult && (
              <>
                {/* Validation Results */}
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                    <div className="flex items-center gap-2 mb-1">
                      <CheckCircle className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs text-emerald-400 font-medium">Valid Leads</span>
                    </div>
                    <p className="text-2xl font-bold text-white">{validationResult.validCount}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
                    <div className="flex items-center gap-2 mb-1">
                      <AlertCircle className="w-4 h-4 text-amber-400" />
                      <span className="text-xs text-amber-400 font-medium">Invalid</span>
                    </div>
                    <p className="text-2xl font-bold text-white">{validationResult.invalidCount}</p>
                  </div>
                </div>

                {validationResult.invalidCount > 0 && (
                  <p className="text-xs text-slate-400 mb-4">
                    {validationResult.invalidCount} rows will be skipped due to invalid or missing phone numbers
                  </p>
                )}

                {/* Progress Bar */}
                {uploadProgress > 0 && (
                  <div className="mb-4">
                    <Progress value={uploadProgress} className="h-1.5 bg-slate-700" />
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2">
                  <Button
                    className="flex-1 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white border-0"
                    disabled={isProcessing || validationResult.validCount === 0}
                    onClick={handleUpload}
                  >
                    {isProcessing ? "Uploading..." : `Import ${validationResult.validCount} Leads`}
                  </Button>
                  <Button
                    variant="outline"
                    className="border-slate-700 text-slate-300 hover:bg-slate-800"
                    onClick={() => { reset(); onCancel?.(); }}
                    disabled={isProcessing}
                  >
                    Cancel
                  </Button>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}