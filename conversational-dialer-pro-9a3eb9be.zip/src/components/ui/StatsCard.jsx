import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

export default function StatsCard({ 
  title, 
  value, 
  subtitle,
  icon: Icon, 
  trend,
  className,
  iconClassName,
  delay = 0
}) {
  const trendValue = typeof trend === 'object' ? trend.value : trend;
  const trendDirection = typeof trend === 'object' ? trend.direction : 'up';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className={cn(
        "relative overflow-hidden rounded-2xl border border-slate-800/50 bg-gradient-to-br from-slate-900 to-slate-950 p-6",
        "hover:border-slate-700/50 transition-all duration-300",
        className
      )}
    >
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 via-transparent to-purple-500/5 pointer-events-none" />
      
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-4">
          <div className={cn(
            "p-3 rounded-xl bg-gradient-to-br",
            iconClassName || "from-blue-500/20 to-blue-600/10"
          )}>
            {Icon && <Icon className="w-5 h-5 text-blue-400" />}
          </div>
          {trendValue && (
            <div className={cn(
              "flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full",
              trendDirection === "up" 
                ? "bg-emerald-500/10 text-emerald-400" 
                : "bg-red-500/10 text-red-400"
            )}>
              <span>{trendDirection === "up" ? "↑" : "↓"}</span>
              <span>{trendValue}</span>
            </div>
          )}
        </div>
        
        <div className="space-y-1">
          <h3 className="text-3xl font-bold text-white tracking-tight">
            {value}
          </h3>
          <p className="text-sm text-slate-400 font-medium">{title}</p>
          {subtitle && (
            <p className="text-xs text-slate-500">{subtitle}</p>
          )}
        </div>
      </div>
    </motion.div>
  );
}