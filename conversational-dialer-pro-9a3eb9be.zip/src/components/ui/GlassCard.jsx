import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

export default function GlassCard({ 
  children, 
  className,
  hover = true,
  delay = 0,
  ...props 
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className={cn(
        "relative overflow-hidden rounded-2xl border border-slate-800/50",
        "bg-gradient-to-br from-slate-900/90 to-slate-950/90 backdrop-blur-xl",
        hover && "hover:border-slate-700/50 hover:shadow-lg hover:shadow-blue-500/5 transition-all duration-300",
        className
      )}
      {...props}
    >
      {/* Glass effect overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/[0.02] to-transparent pointer-events-none" />
      <div className="relative z-10">
        {children}
      </div>
    </motion.div>
  );
}