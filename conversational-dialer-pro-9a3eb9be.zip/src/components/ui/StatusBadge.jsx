import { cn } from "@/lib/utils";

const statusStyles = {
  // Lead statuses
  new: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  dialing: "bg-amber-500/10 text-amber-400 border-amber-500/20 animate-pulse",
  answered: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  qualified: "bg-green-500/10 text-green-400 border-green-500/20",
  disqualified: "bg-red-500/10 text-red-400 border-red-500/20",
  no_answer: "bg-slate-500/10 text-slate-400 border-slate-500/20",
  voicemail: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  callback: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
  
  // Campaign statuses
  draft: "bg-slate-500/10 text-slate-400 border-slate-500/20",
  scheduled: "bg-indigo-500/10 text-indigo-400 border-indigo-500/20",
  running: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20 animate-pulse",
  paused: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  completed: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  
  // Generic
  active: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  inactive: "bg-slate-500/10 text-slate-400 border-slate-500/20",
  pending: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  archived: "bg-slate-600/10 text-slate-500 border-slate-600/20",
  
  // Call outcomes
  positive: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  neutral: "bg-slate-500/10 text-slate-400 border-slate-500/20",
  negative: "bg-red-500/10 text-red-400 border-red-500/20",
};

export default function StatusBadge({ status, className }) {
  const formattedStatus = status?.replace(/_/g, " ") || "unknown";
  
  return (
    <span className={cn(
      "inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border capitalize",
      statusStyles[status] || statusStyles.neutral,
      className
    )}>
      {formattedStatus}
    </span>
  );
}